# ============================================================
# gdu Uninstaller for Windows
# ============================================================
# Usage (관리자 PowerShell):
#   .\uninstall-windows.ps1
# ============================================================

$ErrorActionPreference = "Stop"

$INSTALL_DIR = "$env:PROGRAMFILES\gdu"
$CONFIG_DIR  = "$env:APPDATA\gdu"
$IMAGE_DIR   = "C:\gdu-images"

Write-Host "`n  gdu Windows Uninstaller`n" -ForegroundColor Yellow

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "  [ERROR] 관리자 권한이 필요합니다." -ForegroundColor Red
    exit 1
}

Write-Host "  다음 항목이 삭제됩니다:"
Write-Host "    - $INSTALL_DIR"
Write-Host "    - $CONFIG_DIR"
Write-Host ""
Write-Host "  ※ $IMAGE_DIR 는 삭제하지 않습니다." -ForegroundColor Yellow
Write-Host ""

$response = Read-Host "  계속하시겠습니까? (y/N)"
if ($response -ne "y") {
    Write-Host "  취소됨."
    exit 0
}

# Remove binary directory
if (Test-Path $INSTALL_DIR) {
    Remove-Item -Recurse -Force $INSTALL_DIR
    Write-Host "  [-] $INSTALL_DIR 삭제" -ForegroundColor Green
}

# Remove config
if (Test-Path $CONFIG_DIR) {
    Remove-Item -Recurse -Force $CONFIG_DIR
    Write-Host "  [-] $CONFIG_DIR 삭제" -ForegroundColor Green
}

# Remove from PATH
$currentPath = [System.Environment]::GetEnvironmentVariable("PATH", "Machine")
if ($currentPath -like "*$INSTALL_DIR*") {
    $newPath = ($currentPath -split ";" | Where-Object { $_ -ne $INSTALL_DIR }) -join ";"
    [System.Environment]::SetEnvironmentVariable("PATH", $newPath, "Machine")
    Write-Host "  [-] PATH에서 제거" -ForegroundColor Green
}

Write-Host "`n  gdu 삭제 완료." -ForegroundColor Green
Write-Host "  QEMU 이미지는 $IMAGE_DIR 에 보존됩니다.`n"
