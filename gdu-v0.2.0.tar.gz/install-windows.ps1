# ============================================================
# gdu Installer for Windows (Native)
# ============================================================
# PowerShell 5.1+ / PowerShell 7+
#
# Usage (관리자 권한 PowerShell):
#   Set-ExecutionPolicy Bypass -Scope Process
#   .\install-windows.ps1
#
# 이 스크립트는:
#   1. QEMU for Windows 설치 (winget 또는 Chocolatey)
#   2. Rust 툴체인 설치
#   3. gdu 빌드
#   4. VNC Viewer 설치
#   5. 환경변수 및 PATH 설정
# ============================================================

$ErrorActionPreference = "Stop"

# ── Configuration ────────────────────────────────────────────

$GDU_VERSION  = "0.2.0"
$INSTALL_DIR   = "$env:PROGRAMFILES\gdu"
$CONFIG_DIR    = "$env:APPDATA\gdu"
$IMAGE_DIR     = "C:\gdu-images"
$QEMU_DIR      = "$env:PROGRAMFILES\qemu"

# ── Colors / Helpers ─────────────────────────────────────────

function Write-Banner {
    Write-Host ""
    Write-Host "  ╔═══════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║    ☁ 근두운 (Gunduwoon) v$GDU_VERSION - Windows              ║" -ForegroundColor Cyan
    Write-Host "  ║    Lightweight QEMU Network Lab Emulator           ║" -ForegroundColor Cyan
    Write-Host "  ╚═══════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step($msg)  { Write-Host "`n  ▶ $msg`n" -ForegroundColor Cyan }
function Write-Info($msg)  { Write-Host "  [INFO]  $msg" -ForegroundColor Green }
function Write-Warn($msg)  { Write-Host "  [WARN]  $msg" -ForegroundColor Yellow }
function Write-Err($msg)   { Write-Host "  [ERROR] $msg" -ForegroundColor Red }

function Test-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-Command($cmd) {
    return [bool](Get-Command $cmd -ErrorAction SilentlyContinue)
}

# ── Pre-checks ───────────────────────────────────────────────

Write-Banner

if (-not (Test-Admin)) {
    Write-Err "관리자 권한이 필요합니다."
    Write-Host "  PowerShell을 관리자로 실행한 후 다시 시도하세요." -ForegroundColor Yellow
    exit 1
}

# Check Windows version
$osVersion = [System.Environment]::OSVersion.Version
Write-Info "Windows $($osVersion.Major).$($osVersion.Minor) Build $($osVersion.Build)"

if ($osVersion.Build -lt 17763) {
    Write-Warn "Windows 10 1809 이상을 권장합니다."
}

# ── Step 1: Install QEMU ────────────────────────────────────

function Install-QEMU {
    Write-Step "Step 1/5: QEMU for Windows 설치"

    # Check if already installed
    if (Test-Path "$QEMU_DIR\qemu-system-x86_64.exe") {
        $ver = & "$QEMU_DIR\qemu-system-x86_64.exe" --version 2>&1 | Select-Object -First 1
        Write-Info "QEMU 이미 설치됨: $ver"
        return
    }

    if (Test-Path "C:\Program Files\qemu\qemu-system-x86_64.exe") {
        Write-Info "QEMU 이미 설치됨 (기본 경로)"
        $script:QEMU_DIR = "C:\Program Files\qemu"
        return
    }

    # Try winget first
    if (Test-Command "winget") {
        Write-Info "winget으로 QEMU 설치 중..."
        try {
            winget install --id SoftwareFreedomConservancy.QEMU --accept-source-agreements --accept-package-agreements
            Write-Info "QEMU 설치 완료 (winget) ✓"
            return
        } catch {
            Write-Warn "winget 설치 실패, Chocolatey 시도..."
        }
    }

    # Try Chocolatey
    if (Test-Command "choco") {
        Write-Info "Chocolatey로 QEMU 설치 중..."
        choco install qemu -y
        Write-Info "QEMU 설치 완료 (choco) ✓"
        return
    }

    # Manual download
    Write-Warn "패키지 매니저를 찾을 수 없습니다."
    Write-Host ""
    Write-Host "  QEMU를 수동으로 설치하세요:" -ForegroundColor Yellow
    Write-Host "    https://qemu.weilnetz.de/w64/" -ForegroundColor White
    Write-Host ""
    Write-Host "  또는 winget/Chocolatey를 먼저 설치:" -ForegroundColor Yellow
    Write-Host "    winget: https://github.com/microsoft/winget-cli" -ForegroundColor White
    Write-Host "    choco:  Set-ExecutionPolicy Bypass -Scope Process; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))" -ForegroundColor White
    Write-Host ""

    $response = Read-Host "  QEMU가 이미 설치되어 있습니까? (y/N)"
    if ($response -ne "y") {
        Write-Err "QEMU가 필요합니다. 설치 후 다시 실행하세요."
        exit 1
    }
}

# ── Step 2: Install Rust ────────────────────────────────────

function Install-Rust {
    Write-Step "Step 2/5: Rust 툴체인 설치"

    if (Test-Command "rustc") {
        $ver = rustc --version
        Write-Info "Rust 이미 설치됨: $ver"
        return
    }

    Write-Info "Rust 설치 중..."
    $rustupUrl = "https://win.rustup.rs/x86_64"
    $rustupExe = "$env:TEMP\rustup-init.exe"

    Invoke-WebRequest -Uri $rustupUrl -OutFile $rustupExe
    & $rustupExe -y --default-toolchain stable

    # Refresh PATH
    $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
    $env:PATH += ";$env:USERPROFILE\.cargo\bin"

    Write-Info "Rust 설치 완료 ✓"
}

# ── Step 3: Build gdu ──────────────────────────────────────

function Build-Qdyn {
    Write-Step "Step 3/5: gdu 빌드"

    $scriptDir = Split-Path -Parent $MyInvocation.ScriptName
    if (-not $scriptDir) { $scriptDir = Get-Location }

    if (-not (Test-Path "$scriptDir\Cargo.toml")) {
        Write-Err "Cargo.toml을 찾을 수 없습니다. 프로젝트 루트에서 실행하세요."
        exit 1
    }

    Push-Location $scriptDir

    # Refresh cargo path
    $env:PATH += ";$env:USERPROFILE\.cargo\bin"

    Write-Info "빌드 중... (릴리즈 모드)"
    cargo build --release

    if (-not (Test-Path "$scriptDir\target\release\gdu.exe")) {
        Write-Err "빌드 실패"
        Pop-Location
        exit 1
    }

    Pop-Location
    Write-Info "빌드 완료 ✓"
}

# ── Step 4: Install files ───────────────────────────────────

function Install-Files {
    Write-Step "Step 4/5: 파일 설치"

    $scriptDir = Split-Path -Parent $MyInvocation.ScriptName
    if (-not $scriptDir) { $scriptDir = Get-Location }

    # Create directories
    New-Item -ItemType Directory -Force -Path $INSTALL_DIR | Out-Null
    New-Item -ItemType Directory -Force -Path $CONFIG_DIR | Out-Null
    New-Item -ItemType Directory -Force -Path $IMAGE_DIR | Out-Null
    New-Item -ItemType Directory -Force -Path "$CONFIG_DIR\topologies" | Out-Null

    # Copy binary
    Copy-Item "$scriptDir\target\release\gdu.exe" "$INSTALL_DIR\gdu.exe" -Force
    Write-Info "바이너리: $INSTALL_DIR\gdu.exe"

    # Copy examples
    if (Test-Path "$scriptDir\examples") {
        Copy-Item "$scriptDir\examples\*" "$CONFIG_DIR\topologies\" -Force
        Write-Info "예제 토폴로지: $CONFIG_DIR\topologies\"
    }

    # Default config
    $configFile = "$CONFIG_DIR\gdu.conf"
    if (-not (Test-Path $configFile)) {
        @"
# gdu Global Configuration (Windows)
# ─────────────────────────────────────────

[general]
qemu_binary = "$($QEMU_DIR -replace '\\','\\')\qemu-system-x86_64.exe"
image_dir = "$($IMAGE_DIR -replace '\\','\\')"
topology_dir = "$($CONFIG_DIR -replace '\\','\\')\topologies"

[defaults]
memory = 4096
vcpus = 2
console_base_port = 5000
nic_model = "e1000"

[network]
# Windows uses QEMU user-mode networking or TAP-Windows
network_backend = "user"
enable_haxm = false
enable_whpx = true
"@ | Out-File -FilePath $configFile -Encoding UTF8
        Write-Info "설정파일: $configFile"
    }

    # Add to PATH
    $currentPath = [System.Environment]::GetEnvironmentVariable("PATH", "Machine")
    if ($currentPath -notlike "*$INSTALL_DIR*") {
        [System.Environment]::SetEnvironmentVariable(
            "PATH",
            "$currentPath;$INSTALL_DIR",
            "Machine"
        )
        $env:PATH += ";$INSTALL_DIR"
        Write-Info "PATH에 $INSTALL_DIR 추가 ✓"
    }

    Write-Info "파일 설치 완료 ✓"
}

# ── Step 5: Install VNC/GUI tools ────────────────────────────

function Install-GUITools {
    Write-Step "Step 5/5: GUI 도구 설치"

    # TightVNC Viewer (lightweight VNC client)
    if (Test-Command "winget") {
        Write-Info "VNC Viewer 설치 중..."
        try {
            winget install --id GlavSoft.TightVNCViewer --accept-source-agreements --accept-package-agreements 2>$null
            Write-Info "TightVNC Viewer 설치됨 ✓"
        } catch {
            Write-Warn "VNC Viewer 자동 설치 실패"
        }
    }

    # Check for WHPX (Windows Hypervisor Platform)
    $whpx = Get-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -ErrorAction SilentlyContinue
    if ($whpx -and $whpx.State -eq "Enabled") {
        Write-Info "WHPX (Windows Hypervisor Platform) 활성화됨 ✓"
    } else {
        Write-Warn "WHPX가 비활성화 상태입니다. 성능 향상을 위해 활성화하세요:"
        Write-Host "    Enable-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform" -ForegroundColor White
    }

    # Check for HAXM
    if (Test-Path "$env:PROGRAMFILES\Intel\HAXM") {
        Write-Info "Intel HAXM 감지됨 ✓"
    }

    Write-Info "GUI 도구 설정 완료 ✓"
}

# ── Summary ──────────────────────────────────────────────────

function Write-Summary {
    Write-Host ""
    Write-Host "  ═══════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "    gdu v$GDU_VERSION Windows 설치 완료!" -ForegroundColor Green
    Write-Host "  ═══════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host ""
    Write-Host "  설치 경로:"
    Write-Host "    바이너리      : $INSTALL_DIR\gdu.exe"
    Write-Host "    설정파일      : $CONFIG_DIR\gdu.conf"
    Write-Host "    이미지 디렉토리: $IMAGE_DIR\"
    Write-Host "    토폴로지      : $CONFIG_DIR\topologies\"
    Write-Host ""
    Write-Host "  사용법:" -ForegroundColor Cyan
    Write-Host "    # QEMU 이미지 준비"
    Write-Host "    copy cat8000v.qcow2 $IMAGE_DIR\"
    Write-Host ""
    Write-Host "    # 토폴로지 시작"
    Write-Host "    gdu start $CONFIG_DIR\topologies\ccie-lab.yaml"
    Write-Host ""
    Write-Host "    # Interactive Shell"
    Write-Host "    gdu shell"
    Write-Host ""
    Write-Host "  Windows 네트워킹 참고:" -ForegroundColor Yellow
    Write-Host "    - Windows에서는 TAP-Windows 또는 user-mode 네트워킹 사용"
    Write-Host "    - TAP 어댑터: https://openvpn.net/community-downloads/"
    Write-Host "    - WHPX 가속: Enable-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform"
    Write-Host ""
    Write-Host "  ※ 새 터미널을 열어야 PATH가 적용됩니다." -ForegroundColor Yellow
    Write-Host ""
}

# ── Main ─────────────────────────────────────────────────────

Install-QEMU
Install-Rust
Build-Qdyn
Install-Files
Install-GUITools
Write-Summary
