use anyhow::{Context, Result};
use std::process::Command;

use crate::topology::ConsoleType;
use crate::vm::{VmInstance, VmState};

/// ============================================================
/// Console Manager - v0.2.0
/// ============================================================
/// Supports:
///   - Serial console via telnet (routers, switches)
///   - VNC client launch (GUI appliances)
///   - SPICE client launch (high-perf GUI)
///   - noVNC browser URL (web-based VNC)
///   - Auto-detect best client

pub struct ConsoleManager;

impl ConsoleManager {
    /// Smart connect: auto-detect console type and connect
    pub fn connect(node_name: &str, instance: &VmInstance) -> Result<()> {
        match instance.console_type {
            ConsoleType::Serial => {
                Self::connect_serial(node_name, instance.console_port)
            }
            ConsoleType::Vnc => {
                if let Some(vnc_port) = instance.vnc_port {
                    Self::connect_vnc(node_name, vnc_port, instance.novnc_port)
                } else {
                    println!("  [!] VNC port not assigned for {}", node_name);
                    Self::connect_serial(node_name, instance.console_port)
                }
            }
            ConsoleType::Spice => {
                if let Some(spice_port) = instance.spice_port {
                    Self::connect_spice(node_name, spice_port)
                } else {
                    println!("  [!] SPICE port not assigned for {}", node_name);
                    Self::connect_serial(node_name, instance.console_port)
                }
            }
        }
    }

    /// Connect via telnet serial console
    pub fn connect_serial(node_name: &str, port: u16) -> Result<()> {
        println!("  [*] Serial console → {} (telnet 127.0.0.1:{})", node_name, port);

        let result = Command::new("telnet")
            .args(["127.0.0.1", &port.to_string()])
            .status();

        match result {
            Ok(status) => {
                if status.success() {
                    println!("  [*] Disconnected from {}", node_name);
                }
                Ok(())
            }
            Err(_) => {
                println!("  [!] telnet not found, trying socat...");
                Command::new("socat")
                    .args(["STDIO", &format!("TCP:127.0.0.1:{}", port)])
                    .status()
                    .with_context(|| format!(
                        "Connect manually: telnet 127.0.0.1 {}", port
                    ))?;
                Ok(())
            }
        }
    }

    /// Connect via VNC client
    pub fn connect_vnc(node_name: &str, vnc_port: u16, novnc_port: Option<u16>) -> Result<()> {
        let addr = format!("127.0.0.1:{}", vnc_port);
        println!("  [*] VNC console → {} ({})", node_name, addr);

        // Show noVNC URL if available
        if let Some(nport) = novnc_port {
            println!("  [i] Browser access: http://localhost:{}/vnc.html?host=localhost&port={}",
                nport, nport);
        }

        // Try VNC clients in order of preference
        let vnc_clients: Vec<(&str, Vec<String>)> = vec![
            ("virt-viewer", vec![format!("vnc://127.0.0.1:{}", vnc_port)]),
            ("remote-viewer", vec![format!("vnc://127.0.0.1:{}", vnc_port)]),
            ("vinagre", vec![format!("vnc://127.0.0.1:{}", vnc_port)]),
            ("vncviewer", vec![addr.clone()]),
            ("tigervnc", vec![addr.clone()]),
            ("xtigervncviewer", vec![addr.clone()]),
            ("xtightvncviewer", vec![addr.clone()]),
        ];

        for (client, args) in &vnc_clients {
            let str_args: Vec<&str> = args.iter().map(|s| s.as_str()).collect();
            match Command::new(client).args(&str_args).spawn() {
                Ok(_) => {
                    println!("  [+] {} opened with {}", node_name, client);
                    return Ok(());
                }
                Err(_) => continue,
            }
        }

        // No VNC client found - show manual options
        println!();
        println!("  ┌──────────────────────────────────────────────────┐");
        println!("  │  No VNC client found. Connection options:        │");
        println!("  │                                                  │");
        println!("  │  VNC Client:                                     │");
        println!("  │    vncviewer 127.0.0.1:{}                   │", vnc_port);
        if let Some(nport) = novnc_port {
            println!("  │                                                  │");
            println!("  │  Browser (noVNC):                                │");
            println!("  │    http://localhost:{}/vnc.html            │", nport);
        }
        println!("  │                                                  │");
        println!("  │  Install a VNC client:                           │");
        println!("  │    apt install tigervnc-viewer                   │");
        println!("  │    apt install virt-viewer                       │");
        println!("  │    apt install novnc websockify                  │");
        println!("  └──────────────────────────────────────────────────┘");
        println!();

        Ok(())
    }

    /// Connect via SPICE client
    pub fn connect_spice(node_name: &str, spice_port: u16) -> Result<()> {
        let uri = format!("spice://127.0.0.1:{}", spice_port);
        println!("  [*] SPICE console → {} ({})", node_name, uri);

        let spice_clients: Vec<(&str, Vec<String>)> = vec![
            ("remote-viewer", vec![uri.clone()]),
            ("virt-viewer", vec![format!("--connect={}", uri)]),
            ("spicy", vec!["-h".into(), "127.0.0.1".into(), "-p".into(), spice_port.to_string()]),
        ];

        for (client, args) in &spice_clients {
            let str_args: Vec<&str> = args.iter().map(|s| s.as_str()).collect();
            match Command::new(client).args(&str_args).spawn() {
                Ok(_) => {
                    println!("  [+] {} opened with {}", node_name, client);
                    return Ok(());
                }
                Err(_) => continue,
            }
        }

        println!();
        println!("  ┌──────────────────────────────────────────────────┐");
        println!("  │  No SPICE client found. Connection options:      │");
        println!("  │                                                  │");
        println!("  │    remote-viewer spice://127.0.0.1:{}        │", spice_port);
        println!("  │                                                  │");
        println!("  │  Install a SPICE client:                         │");
        println!("  │    apt install virt-viewer                       │");
        println!("  │    apt install spice-client-gtk                  │");
        println!("  └──────────────────────────────────────────────────┘");
        println!();

        Ok(())
    }

    /// Open console in new terminal window
    pub fn connect_in_terminal(node_name: &str, instance: &VmInstance) -> Result<()> {
        let title = format!("gdu - {}", node_name);

        match instance.console_type {
            ConsoleType::Serial => {
                let cmd = format!("telnet 127.0.0.1 {}", instance.console_port);
                Self::launch_terminal(&title, &cmd, node_name)?;
            }
            ConsoleType::Vnc => {
                if let Some(vnc_port) = instance.vnc_port {
                    // Launch VNC viewer directly
                    let _ = Command::new("vncviewer")
                        .arg(format!("127.0.0.1:{}", vnc_port))
                        .spawn();
                    println!("  [+] VNC viewer for {} launched in background", node_name);
                }
            }
            ConsoleType::Spice => {
                if let Some(spice_port) = instance.spice_port {
                    let _ = Command::new("remote-viewer")
                        .arg(format!("spice://127.0.0.1:{}", spice_port))
                        .spawn();
                    println!("  [+] SPICE viewer for {} launched in background", node_name);
                }
            }
        }
        Ok(())
    }

    fn launch_terminal(title: &str, cmd: &str, node_name: &str) -> Result<()> {
        let terminals = [
            ("xterm", vec!["-T", title, "-e", cmd]),
            ("gnome-terminal", vec!["--title", title, "--", "bash", "-c", cmd]),
            ("konsole", vec!["--title", title, "-e", cmd]),
        ];

        for (term, args) in &terminals {
            let str_args: Vec<&str> = args.iter().map(|s| s.as_str()).collect();
            if Command::new(term).args(&str_args).spawn().is_ok() {
                println!("  [+] Console for {} opened in {}", node_name, term);
                return Ok(());
            }
        }

        println!("  [!] No terminal emulator found.");
        println!("      Connect manually: {}", cmd);
        Ok(())
    }

    /// Show all console connection info (updated for GUI)
    pub fn list_consoles(instances: &std::collections::HashMap<String, VmInstance>) {
        println!();
        println!("  {:<10} {:<8} {:<8} {}", "NODE", "TYPE", "PORT", "CONNECT COMMAND");
        println!("  {}", "─".repeat(70));

        for (name, inst) in instances {
            if inst.state != VmState::Running {
                continue;
            }

            match inst.console_type {
                ConsoleType::Serial => {
                    println!("  {:<10} {:<8} {:<8} telnet 127.0.0.1 {}",
                        name, "serial", inst.console_port, inst.console_port);
                }
                ConsoleType::Vnc => {
                    if let Some(vnc_port) = inst.vnc_port {
                        println!("  {:<10} {:<8} {:<8} vncviewer 127.0.0.1:{}",
                            name, "VNC", vnc_port, vnc_port);
                    }
                    if let Some(novnc_port) = inst.novnc_port {
                        println!("  {:<10} {:<8} {:<8} http://localhost:{}/vnc.html",
                            "", "noVNC", novnc_port, novnc_port);
                    }
                    println!("  {:<10} {:<8} {:<8} telnet 127.0.0.1 {} (serial fallback)",
                        "", "serial", inst.console_port, inst.console_port);
                }
                ConsoleType::Spice => {
                    if let Some(spice_port) = inst.spice_port {
                        println!("  {:<10} {:<8} {:<8} remote-viewer spice://127.0.0.1:{}",
                            name, "SPICE", spice_port, spice_port);
                    }
                    println!("  {:<10} {:<8} {:<8} telnet 127.0.0.1 {} (serial fallback)",
                        "", "serial", inst.console_port, inst.console_port);
                }
            }
        }
        println!();
    }
}
