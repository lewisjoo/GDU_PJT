use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::Path;

/// ============================================================
/// Topology Definition (YAML) - v0.2.0
/// ============================================================
/// Now supports GUI display modes (VNC / SPICE) for appliances
/// like Cisco ISE, Palo Alto, Windows Server, etc.
///
/// ```yaml
/// nodes:
///   ISE:
///     image: "/images/ise-3.3.qcow2"
///     node_type: appliance
///     console_type: vnc
///     display:
///       type: vnc
///       listen: "0.0.0.0"
///       password: "cisco123"
///       web_port: 6080
///     memory: 16384
///     vcpus: 4
///     disk:
///       bus: ide
///       extra_disks:
///         - path: "/images/ise-disk2.qcow2"
///     boot:
///       order: "cd"
///       cdrom: "/images/ise-setup.iso"
/// ```

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Topology {
    pub name: String,
    #[serde(default)]
    pub defaults: NodeDefaults,
    pub nodes: HashMap<String, NodeConfig>,
    #[serde(default)]
    pub links: Vec<LinkConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct NodeDefaults {
    #[serde(default = "default_memory")]
    pub memory: u32,
    #[serde(default = "default_vcpus")]
    pub vcpus: u32,
    #[serde(default = "default_console_base_port")]
    pub console_base_port: u16,
    #[serde(default = "default_vnc_base_port")]
    pub vnc_base_port: u16,
    #[serde(default = "default_spice_base_port")]
    pub spice_base_port: u16,
    #[serde(default = "default_novnc_base_port")]
    pub novnc_base_port: u16,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeConfig {
    pub image: String,
    #[serde(default = "default_node_type")]
    pub node_type: NodeType,
    #[serde(default = "default_console_type")]
    pub console_type: ConsoleType,
    pub memory: Option<u32>,
    pub vcpus: Option<u32>,
    #[serde(default)]
    pub interfaces: Vec<InterfaceConfig>,
    #[serde(default)]
    pub display: Option<DisplayConfig>,
    #[serde(default)]
    pub disk: Option<DiskConfig>,
    #[serde(default)]
    pub boot: Option<BootConfig>,
    #[serde(default)]
    pub extra_qemu_args: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum ConsoleType {
    Serial,
    Vnc,
    Spice,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DisplayConfig {
    #[serde(default = "default_display_type")]
    pub r#type: DisplayType,
    #[serde(default = "default_listen")]
    pub listen: String,
    pub password: Option<String>,
    pub web_port: Option<u16>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum DisplayType {
    Vnc,
    Spice,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiskConfig {
    #[serde(default = "default_disk_bus")]
    pub bus: String,
    #[serde(default = "default_disk_format")]
    pub format: String,
    #[serde(default)]
    pub extra_disks: Vec<ExtraDisk>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExtraDisk {
    pub path: String,
    pub size: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BootConfig {
    #[serde(default = "default_boot_order")]
    pub order: String,
    pub cdrom: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum NodeType {
    Router,
    Switch,
    Firewall,
    Host,
    Appliance,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InterfaceConfig {
    pub name: String,
    pub bridge: String,
    #[serde(default = "default_nic_model")]
    pub model: String,
    pub mac: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LinkConfig {
    pub name: String,
    #[serde(default)]
    pub mtu: Option<u32>,
}

fn default_memory() -> u32 { 4096 }
fn default_vcpus() -> u32 { 2 }
fn default_console_base_port() -> u16 { 5000 }
fn default_vnc_base_port() -> u16 { 5900 }
fn default_spice_base_port() -> u16 { 5950 }
fn default_novnc_base_port() -> u16 { 6080 }
fn default_node_type() -> NodeType { NodeType::Router }
fn default_console_type() -> ConsoleType { ConsoleType::Serial }
fn default_nic_model() -> String { "virtio-net-pci".to_string() }
fn default_display_type() -> DisplayType { DisplayType::Vnc }
fn default_listen() -> String { "0.0.0.0".to_string() }
fn default_disk_bus() -> String { "virtio".to_string() }
fn default_disk_format() -> String { "qcow2".to_string() }
fn default_boot_order() -> String { "c".to_string() }

impl Topology {
    pub fn from_file(path: &Path) -> Result<Self> {
        let content = std::fs::read_to_string(path)
            .with_context(|| format!("Failed to read topology file: {}", path.display()))?;
        let topo: Topology = serde_yaml::from_str(&content)
            .with_context(|| "Failed to parse topology YAML")?;
        topo.validate()?;
        Ok(topo)
    }

    pub fn validate(&self) -> Result<()> {
        let link_names: Vec<&str> = self.links.iter().map(|l| l.name.as_str()).collect();

        for (node_name, node) in &self.nodes {
            if !Path::new(&node.image).exists() {
                eprintln!("  [WARN] Image not found for {}: {}", node_name, node.image);
            }
            for iface in &node.interfaces {
                if !link_names.contains(&iface.bridge.as_str()) {
                    anyhow::bail!(
                        "Node '{}' interface '{}' references undefined link '{}'",
                        node_name, iface.name, iface.bridge
                    );
                }
            }
            if (node.console_type == ConsoleType::Vnc || node.console_type == ConsoleType::Spice)
                && node.display.is_none()
            {
                eprintln!(
                    "  [WARN] Node '{}' has console_type={:?} but no display config. Using defaults.",
                    node_name, node.console_type
                );
            }
            if let Some(ref boot) = node.boot {
                if let Some(ref cdrom) = boot.cdrom {
                    if !Path::new(cdrom).exists() {
                        eprintln!("  [WARN] CDROM not found for {}: {}", node_name, cdrom);
                    }
                }
            }
        }
        Ok(())
    }

    pub fn effective_memory(&self, node: &NodeConfig) -> u32 {
        node.memory.unwrap_or(self.defaults.memory)
    }

    pub fn effective_vcpus(&self, node: &NodeConfig) -> u32 {
        node.vcpus.unwrap_or(self.defaults.vcpus)
    }

    pub fn has_gui_nodes(&self) -> bool {
        self.nodes.values().any(|n| {
            n.console_type == ConsoleType::Vnc || n.console_type == ConsoleType::Spice
        })
    }
}
