use anyhow::{Context, Result};
use std::collections::HashMap;
use std::process::Command;

use crate::topology::LinkConfig;

/// ============================================================
/// Network Link Manager
/// ============================================================
/// Creates Linux bridges for inter-VM connectivity.
/// Each "link" in the topology becomes a Linux bridge,
/// and each VM interface becomes a TAP device attached
/// to that bridge.
///
/// Topology Link  →  Linux Bridge  (br-<link_name>)
/// VM Interface   →  TAP Device    (<node>_<iface>)
///                    └── attached to bridge

pub struct NetworkManager {
    bridges: HashMap<String, BridgeInfo>,
}

#[derive(Debug)]
pub struct BridgeInfo {
    pub name: String,
    pub link_name: String,
    pub taps: Vec<String>,
    pub is_up: bool,
}

impl NetworkManager {
    pub fn new() -> Self {
        Self {
            bridges: HashMap::new(),
        }
    }

    /// Create all bridges defined in topology links
    pub fn create_bridges(&mut self, links: &[LinkConfig]) -> Result<()> {
        println!("\n=== Creating network bridges ===\n");

        for link in links {
            let br_name = format!("br-{}", link.name);
            self.create_bridge(&br_name, &link.name, link.mtu)?;
        }

        println!("\n=== Bridges ready ===\n");
        Ok(())
    }

    /// Create a single Linux bridge
    fn create_bridge(&mut self, br_name: &str, link_name: &str, mtu: Option<u32>) -> Result<()> {
        // ip link add <bridge> type bridge
        run_cmd("ip", &["link", "add", br_name, "type", "bridge"])
            .with_context(|| format!("Failed to create bridge {}", br_name))?;

        // Set MTU if specified
        if let Some(mtu_val) = mtu {
            run_cmd("ip", &["link", "set", br_name, "mtu", &mtu_val.to_string()])?;
        }

        // Bring bridge up
        run_cmd("ip", &["link", "set", br_name, "up"])
            .with_context(|| format!("Failed to bring up bridge {}", br_name))?;

        // Disable STP (for lab simplicity)
        let stp_path = format!("/sys/class/net/{}/bridge/stp_state", br_name);
        let _ = std::fs::write(&stp_path, "0");

        println!("  [+] Bridge: {} (link: {})", br_name, link_name);

        self.bridges.insert(link_name.to_string(), BridgeInfo {
            name: br_name.to_string(),
            link_name: link_name.to_string(),
            taps: Vec::new(),
            is_up: true,
        });

        Ok(())
    }

    /// Create a TAP interface and attach to bridge
    pub fn create_tap(&mut self, tap_name: &str, link_name: &str) -> Result<()> {
        let bridge = self.bridges.get_mut(link_name)
            .with_context(|| format!("Bridge for link '{}' not found", link_name))?;

        // Sanitize tap name (max 15 chars for Linux)
        let safe_tap = sanitize_ifname(tap_name);

        // Create TAP
        run_cmd("ip", &["tuntap", "add", &safe_tap, "mode", "tap"])?;
        run_cmd("ip", &["link", "set", &safe_tap, "up"])?;

        // Attach to bridge
        run_cmd("ip", &["link", "set", &safe_tap, "master", &bridge.name])?;

        println!("  [+] TAP: {} → {}", safe_tap, bridge.name);
        bridge.taps.push(safe_tap);

        Ok(())
    }

    /// Destroy all bridges and TAPs
    pub fn cleanup(&mut self) -> Result<()> {
        println!("\n=== Cleaning up network ===\n");

        for (_link, bridge) in &self.bridges {
            // Remove TAPs
            for tap in &bridge.taps {
                let _ = run_cmd("ip", &["link", "delete", tap]);
                println!("  [-] TAP: {}", tap);
            }
            // Remove bridge
            let _ = run_cmd("ip", &["link", "set", &bridge.name, "down"]);
            let _ = run_cmd("ip", &["link", "delete", &bridge.name, "type", "bridge"]);
            println!("  [-] Bridge: {}", bridge.name);
        }

        self.bridges.clear();
        println!("\n=== Network cleaned up ===");
        Ok(())
    }

    /// List all bridges and their TAPs
    pub fn list_bridges(&self) {
        println!("{:<20} {:<20} {:<6} {}",
            "LINK", "BRIDGE", "UP", "TAPS");
        println!("{}", "-".repeat(70));

        for (_, br) in &self.bridges {
            println!("{:<20} {:<20} {:<6} {}",
                br.link_name,
                br.name,
                if br.is_up { "YES" } else { "NO" },
                br.taps.join(", "));
        }
    }
}

/// Run an external command, returning Ok if successful
fn run_cmd(program: &str, args: &[&str]) -> Result<()> {
    let output = Command::new(program)
        .args(args)
        .output()
        .with_context(|| format!("Failed to execute: {} {}", program, args.join(" ")))?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        anyhow::bail!("{} {} failed: {}", program, args.join(" "), stderr.trim());
    }
    Ok(())
}

/// Sanitize interface name to Linux limit (15 chars, no special chars)
fn sanitize_ifname(name: &str) -> String {
    let clean: String = name
        .replace("/", "_")
        .replace(" ", "")
        .chars()
        .filter(|c| c.is_alphanumeric() || *c == '_' || *c == '-')
        .collect();
    if clean.len() > 15 {
        clean[..15].to_string()
    } else {
        clean
    }
}
