#!/bin/bash
# ============================================================
# gdu Installer for WSL2 (Windows Subsystem for Linux)
# ============================================================
#
# Usage (WSL2 터미널에서):
#   chmod +x install-wsl2.sh
#   sudo ./install-wsl2.sh
#
# 이 스크립트는:
#   1. WSL2 환경 감지 및 검증
#   2. QEMU + KVM 설치 (WSL2 커널 5.10+ KVM 지원)
#   3. Rust 툴체인 설치
#   4. gdu 빌드 및 설치
#   5. VNC → Windows 브라우저 연동 (noVNC)
#   6. WSL2 네트워크 포워딩 설정
#
# WSL2 장점:
#   - Linux KVM 가속 사용 가능 (Windows 11 / WSL 5.10+)
#   - Linux 네트워크 스택 (Bridge/TAP) 그대로 사용
#   - Windows 브라우저에서 noVNC로 GUI 접속
#   - Windows 파일시스템과 이미지 공유 (/mnt/c/)
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

INSTALL_DIR="/opt/gdu"
BIN_DIR="/usr/local/bin"
CONFIG_DIR="/etc/gdu"
IMAGE_DIR="/opt/qemu-images"
LOG_DIR="/var/log/gdu"
LIB_DIR="/var/lib/gdu"

log_info()  { echo -e "  ${GREEN}[INFO]${NC}  $1"; }
log_warn()  { echo -e "  ${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "  ${RED}[ERROR]${NC} $1"; }
log_step()  { echo -e "\n  ${CYAN}▶ $1${NC}\n"; }

print_banner() {
    echo -e "${CYAN}"
    echo "  ╔═══════════════════════════════════════════════════╗"
    echo "  ║    ☁ 근두운 (Gunduwoon) v0.2.0 - WSL2 Edition           ║"
    echo "  ║    Lightweight QEMU Network Lab Emulator            ║"
    echo "  ║    Linux Power + Windows GUI                       ║"
    echo "  ╚═══════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# ── Pre-checks ───────────────────────────────────────────────

check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "sudo로 실행하세요: sudo ./install-wsl2.sh"
        exit 1
    fi
}

check_wsl2() {
    log_step "Step 0: WSL2 환경 검증"

    # Check if running in WSL
    if ! grep -qi "microsoft\|wsl" /proc/version 2>/dev/null; then
        log_error "WSL 환경이 아닙니다."
        log_error "이 스크립트는 WSL2에서만 실행 가능합니다."
        echo ""
        echo "  WSL2 설치:"
        echo "    PowerShell (관리자): wsl --install -d Ubuntu-22.04"
        echo ""
        exit 1
    fi

    # Check WSL version
    WSL_VERSION="unknown"
    if [ -f /proc/version ]; then
        if grep -qi "WSL2\|microsoft-standard" /proc/version; then
            WSL_VERSION="2"
            log_info "WSL2 감지됨 ✓"
        else
            WSL_VERSION="1"
            log_warn "WSL1이 감지되었습니다. WSL2로 업그레이드를 권장합니다."
            log_warn "  PowerShell: wsl --set-version <distro> 2"
        fi
    fi

    # Check kernel version for KVM support
    KERNEL_VER=$(uname -r)
    log_info "커널: $KERNEL_VER"

    KERNEL_MAJOR=$(echo "$KERNEL_VER" | cut -d. -f1)
    KERNEL_MINOR=$(echo "$KERNEL_VER" | cut -d. -f2)

    if [ "$KERNEL_MAJOR" -ge 5 ] && [ "$KERNEL_MINOR" -ge 10 ]; then
        log_info "커널 5.10+ - KVM 가속 가능 ✓"
    else
        log_warn "커널 $KERNEL_VER - KVM 지원이 제한적일 수 있습니다."
        log_warn "  Windows 업데이트 후: wsl --update"
    fi

    # Check KVM
    if [ -e /dev/kvm ]; then
        log_info "/dev/kvm 존재 - KVM 가속 사용 가능 ✓"
    else
        log_warn "/dev/kvm 없음"
        log_warn "KVM 활성화 방법:"
        echo ""
        echo "  1. Windows 기능 활성화 (PowerShell 관리자):"
        echo "     Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform"
        echo "     Enable-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform"
        echo ""
        echo "  2. WSL .wslconfig 설정 (C:\\Users\\<user>\\.wslconfig):"
        echo "     [wsl2]"
        echo "     nestedVirtualization=true"
        echo "     memory=16GB"
        echo "     processors=4"
        echo ""
        echo "  3. 재부팅 후 WSL 재시작: wsl --shutdown && wsl"
        echo ""

        read -p "  KVM 없이 계속 진행하시겠습니까? (y/N) " -n 1 -r
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi

    # Get Windows username for path references
    WIN_USER=$(cmd.exe /c "echo %USERNAME%" 2>/dev/null | tr -d '\r' || echo "unknown")
    log_info "Windows 사용자: $WIN_USER"
}

# ── Step 1: Install Dependencies ─────────────────────────────

install_dependencies() {
    log_step "Step 1/5: 시스템 패키지 설치"

    apt-get update -qq

    apt-get install -y -qq \
        qemu-system-x86 \
        qemu-utils \
        bridge-utils \
        iproute2 \
        telnet \
        socat \
        net-tools \
        curl \
        build-essential \
        pkg-config \
        libssl-dev \
        novnc \
        websockify \
        > /dev/null 2>&1

    # WSL2 specific: install wslu for Windows integration
    apt-get install -y -qq wslu 2>/dev/null || true

    log_info "QEMU: $(qemu-system-x86_64 --version | head -1)"
    log_info "패키지 설치 완료 ✓"
}

# ── Step 2: Install Rust ─────────────────────────────────────

install_rust() {
    log_step "Step 2/5: Rust 툴체인 설치"

    if command -v rustc &> /dev/null; then
        log_info "Rust 이미 설치됨: $(rustc --version)"
        return
    fi

    REAL_USER="${SUDO_USER:-$USER}"
    REAL_HOME=$(eval echo "~$REAL_USER")

    su - "$REAL_USER" -c 'curl --proto "=https" --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y' \
        > /dev/null 2>&1

    export PATH="$REAL_HOME/.cargo/bin:$PATH"
    log_info "Rust 설치 완료 ✓"
}

# ── Step 3: Build gdu ───────────────────────────────────────

build_gdu() {
    log_step "Step 3/5: gdu 빌드"

    REAL_USER="${SUDO_USER:-$USER}"
    REAL_HOME=$(eval echo "~$REAL_USER")
    export PATH="$REAL_HOME/.cargo/bin:$PATH"

    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

    if [ ! -f "$SCRIPT_DIR/Cargo.toml" ]; then
        log_error "Cargo.toml을 찾을 수 없습니다."
        exit 1
    fi

    cd "$SCRIPT_DIR"
    log_info "빌드 중..."
    su - "$REAL_USER" -c "cd $SCRIPT_DIR && cargo build --release 2>&1" | tail -5

    if [ ! -f "$SCRIPT_DIR/target/release/gdu" ]; then
        log_error "빌드 실패"
        exit 1
    fi

    log_info "빌드 완료 ✓"
}

# ── Step 4: Install files ────────────────────────────────────

install_files() {
    log_step "Step 4/5: 파일 설치"

    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

    install -m 0755 "$SCRIPT_DIR/target/release/gdu" "$BIN_DIR/gdu"
    log_info "바이너리: $BIN_DIR/gdu"

    mkdir -p "$CONFIG_DIR" "$IMAGE_DIR" "$LOG_DIR" "$LIB_DIR/topologies"

    # Copy examples
    if [ -d "$SCRIPT_DIR/examples" ]; then
        cp -r "$SCRIPT_DIR/examples/"* "$LIB_DIR/topologies/" 2>/dev/null || true
    fi

    # WSL2-specific config
    if [ ! -f "$CONFIG_DIR/gdu.conf" ]; then
        cat > "$CONFIG_DIR/gdu.conf" << 'CONF'
# gdu Global Configuration (WSL2)
# ─────────────────────────────────────────

[general]
qemu_binary = ""
image_dir = "/opt/qemu-images"
topology_dir = "/var/lib/gdu/topologies"
log_dir = "/var/log/gdu"

[defaults]
memory = 4096
vcpus = 2
console_base_port = 5000
vnc_base_port = 5900
novnc_base_port = 6080
nic_model = "virtio-net-pci"

[network]
bridge_prefix = "br-"
enable_kvm = true
snapshot_mode = true

[wsl2]
# Windows 브라우저 자동 실행 (noVNC 접속)
auto_open_browser = true
# Windows 이미지 경로 매핑 (선택)
# win_image_dir = "/mnt/c/Users/<user>/gdu-images"
CONF
        log_info "설정파일: $CONFIG_DIR/gdu.conf"
    fi

    # Create Windows-accessible symlink for images
    WIN_USER=$(cmd.exe /c "echo %USERNAME%" 2>/dev/null | tr -d '\r' || echo "")
    if [ -n "$WIN_USER" ] && [ -d "/mnt/c/Users/$WIN_USER" ]; then
        WIN_IMG_DIR="/mnt/c/Users/$WIN_USER/gdu-images"
        mkdir -p "$WIN_IMG_DIR" 2>/dev/null || true
        ln -sf "$WIN_IMG_DIR" "$IMAGE_DIR/windows-shared" 2>/dev/null || true
        log_info "Windows 이미지 공유: C:\\Users\\$WIN_USER\\gdu-images"
    fi

    # Bash completion
    cat > /etc/bash_completion.d/gdu << 'COMP'
_gdu() {
    local cur prev opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    case "$prev" in
        gdu)
            opts="start stop list console vnc spice browser shell validate help"
            COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
            ;;
        start|validate|load)
            COMPREPLY=( $(compgen -f -X '!*.yaml' -- "$cur") )
            ;;
    esac
}
complete -F _gdu gdu
COMP

    log_info "설치 완료 ✓"
}

# ── Step 5: WSL2-specific configuration ──────────────────────

configure_wsl2() {
    log_step "Step 5/5: WSL2 전용 설정"

    # IP forwarding
    if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
        echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
        sysctl -w net.ipv4.ip_forward=1 > /dev/null 2>&1 || true
        log_info "IP Forwarding 활성화 ✓"
    fi

    # KVM group
    REAL_USER="${SUDO_USER:-$USER}"
    usermod -aG kvm "$REAL_USER" 2>/dev/null || true
    log_info "KVM 그룹 추가 ✓"

    # Create helper script to open noVNC in Windows browser
    cat > "$BIN_DIR/gdu-browser" << 'BROWSER'
#!/bin/bash
# Open noVNC URL in Windows default browser from WSL2
PORT=${1:-6080}
HOST=$(hostname -I | awk '{print $1}')
URL="http://${HOST}:${PORT}/vnc.html?host=${HOST}&port=${PORT}"

echo "  Opening in Windows browser: $URL"

# Try wslview (wslu package)
if command -v wslview &> /dev/null; then
    wslview "$URL"
# Try powershell.exe
elif command -v powershell.exe &> /dev/null; then
    powershell.exe -Command "Start-Process '$URL'"
# Try cmd.exe
elif command -v cmd.exe &> /dev/null; then
    cmd.exe /c "start $URL"
else
    echo "  Could not open browser. Visit: $URL"
fi
BROWSER
    chmod +x "$BIN_DIR/gdu-browser"
    log_info "Windows 브라우저 헬퍼: gdu-browser <port>"

    # Create .wslconfig template
    WIN_USER=$(cmd.exe /c "echo %USERNAME%" 2>/dev/null | tr -d '\r' || echo "")
    WSLCONFIG="/mnt/c/Users/$WIN_USER/.wslconfig"

    if [ -n "$WIN_USER" ] && [ ! -f "$WSLCONFIG" ]; then
        cat > "$WSLCONFIG" << 'WSLCFG'
# WSL2 Configuration for gdu
# ─────────────────────────────────────────
[wsl2]
# gdu 권장 설정
memory=16GB
processors=4
nestedVirtualization=true
swap=4GB

# 네트워크 (WSL2 미러 모드 - Windows 11 22H2+)
# networkingMode=mirrored
WSLCFG
        log_info ".wslconfig 생성됨: C:\\Users\\$WIN_USER\\.wslconfig"
        log_warn "적용하려면 PowerShell에서 'wsl --shutdown' 후 WSL 재시작 필요"
    fi

    # Port forwarding helper
    cat > "$BIN_DIR/gdu-portfwd" << 'PORTFWD'
#!/bin/bash
# ============================================================
# WSL2 → Windows 포트 포워딩 설정
# ============================================================
# WSL2는 별도 IP를 사용하므로, Windows에서 localhost로
# 접속하려면 포트 포워딩이 필요합니다.
#
# Usage:
#   sudo gdu-portfwd setup     # 포트 포워딩 설정
#   sudo gdu-portfwd status    # 상태 확인
#   sudo gdu-portfwd clean     # 제거
# ============================================================

WSL_IP=$(hostname -I | awk '{print $1}')

# gdu에서 사용하는 포트 범위
PORTS_SERIAL="5000-5020"      # telnet serial console
PORTS_VNC="5900-5910"         # VNC
PORTS_SPICE="5950-5960"       # SPICE
PORTS_NOVNC="6080-6090"       # noVNC
PORTS_MONITOR="6000-6020"     # QEMU monitor

case "$1" in
    setup)
        echo "  WSL2 IP: $WSL_IP"
        echo "  Setting up port forwarding..."

        for RANGE in $PORTS_SERIAL $PORTS_VNC $PORTS_SPICE $PORTS_NOVNC $PORTS_MONITOR; do
            START=$(echo $RANGE | cut -d- -f1)
            END=$(echo $RANGE | cut -d- -f2)
            for PORT in $(seq $START $END); do
                powershell.exe -Command "netsh interface portproxy add v4tov4 listenport=$PORT listenaddress=0.0.0.0 connectport=$PORT connectaddress=$WSL_IP" 2>/dev/null
            done
            echo "  [+] Forwarded: $RANGE → $WSL_IP"
        done

        # Firewall rule
        powershell.exe -Command "New-NetFireWallRule -DisplayName 'gdu-WSL2' -Direction Inbound -LocalPort 5000-6100 -Protocol TCP -Action Allow" 2>/dev/null || true
        echo "  [+] Firewall rule added"
        echo ""
        echo "  Windows에서 접속:"
        echo "    Serial:  telnet localhost 5000"
        echo "    VNC:     vncviewer localhost:5900"
        echo "    noVNC:   http://localhost:6080/vnc.html"
        ;;

    status)
        echo "  WSL2 IP: $WSL_IP"
        echo "  현재 포트 포워딩:"
        powershell.exe -Command "netsh interface portproxy show v4tov4" 2>/dev/null
        ;;

    clean)
        echo "  포트 포워딩 제거 중..."
        for RANGE in $PORTS_SERIAL $PORTS_VNC $PORTS_SPICE $PORTS_NOVNC $PORTS_MONITOR; do
            START=$(echo $RANGE | cut -d- -f1)
            END=$(echo $RANGE | cut -d- -f2)
            for PORT in $(seq $START $END); do
                powershell.exe -Command "netsh interface portproxy delete v4tov4 listenport=$PORT listenaddress=0.0.0.0" 2>/dev/null
            done
        done
        powershell.exe -Command "Remove-NetFireWallRule -DisplayName 'gdu-WSL2'" 2>/dev/null || true
        echo "  [+] 제거 완료"
        ;;

    *)
        echo "Usage: gdu-portfwd {setup|status|clean}"
        ;;
esac
PORTFWD
    chmod +x "$BIN_DIR/gdu-portfwd"
    log_info "포트 포워딩 헬퍼: sudo gdu-portfwd setup"
}

# ── Summary ──────────────────────────────────────────────────

print_summary() {
    WSL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "unknown")
    WIN_USER=$(cmd.exe /c "echo %USERNAME%" 2>/dev/null | tr -d '\r' || echo "unknown")

    echo ""
    echo -e "  ${GREEN}═══════════════════════════════════════════════════${NC}"
    echo -e "  ${GREEN}  gdu v0.2.0 WSL2 설치 완료!${NC}"
    echo -e "  ${GREEN}═══════════════════════════════════════════════════${NC}"
    echo ""
    echo "  WSL2 IP: $WSL_IP"
    echo ""
    echo "  ── 설치 경로 ──"
    echo "    바이너리        : $BIN_DIR/gdu"
    echo "    설정파일        : $CONFIG_DIR/gdu.conf"
    echo "    이미지 (Linux)  : $IMAGE_DIR/"
    echo "    이미지 (Windows): C:\\Users\\$WIN_USER\\gdu-images"
    echo "    토폴로지        : $LIB_DIR/topologies/"
    echo ""
    echo "  ── 초기 설정 (최초 1회) ──"
    echo ""
    echo "    # 1. 포트 포워딩 설정 (Windows에서 localhost 접속용)"
    echo "    sudo gdu-portfwd setup"
    echo ""
    echo "    # 2. 이미지 준비 (Windows에서 복사)"
    echo "    cp /mnt/c/Users/$WIN_USER/Downloads/cat8000v.qcow2 $IMAGE_DIR/"
    echo ""
    echo "  ── 사용법 ──"
    echo ""
    echo "    # 토폴로지 시작"
    echo "    sudo gdu start $LIB_DIR/topologies/enterprise-gui-lab.yaml"
    echo ""
    echo "    # Interactive Shell"
    echo "    sudo gdu shell"
    echo ""
    echo "  ── Windows에서 접속 ──"
    echo ""
    echo "    Serial (Router): telnet localhost 5000"
    echo "    VNC (ISE):       vncviewer localhost:5900"
    echo "    Browser (noVNC): http://localhost:6080/vnc.html"
    echo "    SPICE (WinSrv):  remote-viewer spice://localhost:5950"
    echo ""
    echo "    ※ Windows 브라우저 자동 실행: gdu-browser 6080"
    echo ""

    if [ ! -e /dev/kvm ]; then
        echo -e "  ${YELLOW}⚠ KVM이 비활성화 상태입니다.${NC}"
        echo "    .wslconfig에 nestedVirtualization=true 설정 후"
        echo "    PowerShell: wsl --shutdown && wsl"
        echo ""
    fi
}

# ── Main ─────────────────────────────────────────────────────

main() {
    print_banner
    check_root
    check_wsl2
    install_dependencies
    install_rust
    build_gdu
    install_files
    configure_wsl2
    print_summary
}

main "$@"
