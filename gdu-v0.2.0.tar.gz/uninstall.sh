#!/bin/bash
# ============================================================
# gdu Uninstaller for Ubuntu
# ============================================================
# Usage:
#   sudo ./uninstall.sh
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "\n  ${YELLOW}gdu Uninstaller${NC}\n"

if [ "$EUID" -ne 0 ]; then
    echo -e "  ${RED}[ERROR]${NC} root 권한이 필요합니다."
    exit 1
fi

echo "  다음 항목이 삭제됩니다:"
echo "    - /usr/local/bin/gdu"
echo "    - /etc/gdu/"
echo "    - /var/log/gdu/"
echo "    - /var/lib/gdu/"
echo "    - /etc/systemd/system/gdu@.service"
echo "    - /etc/bash_completion.d/gdu"
echo ""
echo -e "  ${YELLOW}※ /opt/qemu-images/ 는 삭제하지 않습니다.${NC}"
echo ""
read -p "  계속하시겠습니까? (y/N) " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "  취소됨."
    exit 0
fi

# Stop any running services
systemctl stop 'gdu@*' 2>/dev/null || true
systemctl disable 'gdu@*' 2>/dev/null || true

# Remove files
rm -f /usr/local/bin/gdu
rm -rf /etc/gdu
rm -rf /var/log/gdu
rm -rf /var/lib/gdu
rm -f /etc/systemd/system/gdu@.service
rm -f /etc/bash_completion.d/gdu

systemctl daemon-reload

echo -e "\n  ${GREEN}gdu 삭제 완료.${NC}"
echo "  QEMU 이미지는 /opt/qemu-images/ 에 보존됩니다."
echo ""
