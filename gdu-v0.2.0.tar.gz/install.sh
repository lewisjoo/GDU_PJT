#!/bin/bash
# ============================================================
# gdu Installer for Ubuntu 20.04 / 22.04 / 24.04
# ============================================================
# Usage:
#   chmod +x install.sh
#   sudo ./install.sh
# ============================================================

set -e

# ── Colors ──────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

INSTALL_DIR="/opt/gdu"
BIN_DIR="/usr/local/bin"
CONFIG_DIR="/etc/gdu"
IMAGE_DIR="/opt/qemu-images"
LOG_DIR="/var/log/gdu"
LIB_DIR="/var/lib/gdu"

# ── Functions ───────────────────────────────────────────────

print_banner() {
    echo -e "${CYAN}"
    echo "  ╔═══════════════════════════════════════════════════╗"
    echo "  ║          ☁ 근두운 (Gunduwoon) v0.2.0                    ║"
    echo "  ║   Lightweight QEMU Network Lab Emulator            ║"
    echo "  ╚═══════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

log_info()    { echo -e "  ${GREEN}[INFO]${NC}  $1"; }
log_warn()    { echo -e "  ${YELLOW}[WARN]${NC}  $1"; }
log_error()   { echo -e "  ${RED}[ERROR]${NC} $1"; }
log_step()    { echo -e "\n  ${CYAN}▶ $1${NC}\n"; }

check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "root 권한이 필요합니다. sudo ./install.sh 로 실행하세요."
        exit 1
    fi
}

check_ubuntu() {
    if [ ! -f /etc/os-release ]; then
        log_error "Ubuntu가 아닌 환경입니다."
        exit 1
    fi
    . /etc/os-release
    log_info "OS 감지: $PRETTY_NAME"
}

check_kvm() {
    if [ ! -e /dev/kvm ]; then
        log_warn "/dev/kvm이 없습니다. 중첩 가상화 또는 베어메탈 환경이 필요합니다."
        log_warn "KVM 없이도 설치는 진행되지만, VM 성능이 매우 저하됩니다."
        echo ""
        read -p "  계속 진행하시겠습니까? (y/N) " -n 1 -r
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    else
        log_info "KVM 지원 확인됨 ✓"
    fi
}

# ── Step 1: System Dependencies ─────────────────────────────

install_dependencies() {
    log_step "Step 1/5: 시스템 패키지 설치"

    apt-get update -qq

    apt-get install -y -qq \
        qemu-system-x86 \
        qemu-utils \
        bridge-utils \
        iproute2 \
        telnet \
        socat \
        net-tools \
        curl \
        build-essential \
        pkg-config \
        libssl-dev \
        novnc \
        websockify \
        tigervnc-viewer \
        virt-viewer \
        spice-client-gtk \
        > /dev/null 2>&1

    log_info "QEMU 버전: $(qemu-system-x86_64 --version | head -1)"
    log_info "시스템 패키지 설치 완료 ✓"
}

# ── Step 2: Install Rust ─────────────────────────────────────

install_rust() {
    log_step "Step 2/5: Rust 툴체인 설치"

    if command -v rustc &> /dev/null; then
        log_info "Rust 이미 설치됨: $(rustc --version)"
    else
        log_info "Rust 설치 중..."
        # Install for the real user (not root)
        REAL_USER="${SUDO_USER:-$USER}"
        REAL_HOME=$(eval echo "~$REAL_USER")

        su - "$REAL_USER" -c 'curl --proto "=https" --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y' \
            > /dev/null 2>&1

        # Source for current session
        export PATH="$REAL_HOME/.cargo/bin:$PATH"
        log_info "Rust 설치 완료: $(rustc --version 2>/dev/null || echo 'installed')"
    fi
}

# ── Step 3: Build gdu ───────────────────────────────────────

build_gdu() {
    log_step "Step 3/5: gdu 빌드"

    REAL_USER="${SUDO_USER:-$USER}"
    REAL_HOME=$(eval echo "~$REAL_USER")
    export PATH="$REAL_HOME/.cargo/bin:$PATH"

    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

    # Check if Cargo.toml exists in the same directory
    if [ ! -f "$SCRIPT_DIR/Cargo.toml" ]; then
        log_error "Cargo.toml을 찾을 수 없습니다. 프로젝트 루트에서 실행하세요."
        exit 1
    fi

    cd "$SCRIPT_DIR"

    log_info "빌드 중... (릴리즈 모드)"
    su - "$REAL_USER" -c "cd $SCRIPT_DIR && cargo build --release 2>&1" | tail -5

    if [ ! -f "$SCRIPT_DIR/target/release/gdu" ]; then
        log_error "빌드 실패"
        exit 1
    fi

    log_info "빌드 완료 ✓"
}

# ── Step 4: Install files ────────────────────────────────────

install_files() {
    log_step "Step 4/5: 파일 설치"

    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

    # Binary
    install -m 0755 "$SCRIPT_DIR/target/release/gdu" "$BIN_DIR/gdu"
    log_info "바이너리: $BIN_DIR/gdu"

    # Directories
    mkdir -p "$CONFIG_DIR"
    mkdir -p "$IMAGE_DIR"
    mkdir -p "$LOG_DIR"
    mkdir -p "$LIB_DIR/topologies"

    # Default config
    if [ ! -f "$CONFIG_DIR/gdu.conf" ]; then
        cat > "$CONFIG_DIR/gdu.conf" << 'CONF'
# gdu Global Configuration
# ─────────────────────────────────────────

[general]
# QEMU binary path (auto-detected if empty)
qemu_binary = ""

# Default image directory
image_dir = "/opt/qemu-images"

# Topology search path
topology_dir = "/var/lib/gdu/topologies"

# Log directory
log_dir = "/var/log/gdu"

[defaults]
# Default VM settings (overridden by topology YAML)
memory = 4096
vcpus = 2
console_base_port = 5000
nic_model = "virtio-net-pci"

[network]
# Bridge prefix
bridge_prefix = "br-"

# Enable KVM acceleration
enable_kvm = true

# Snapshot mode (preserve original images)
snapshot_mode = true
CONF
        log_info "설정파일: $CONFIG_DIR/gdu.conf"
    fi

    # Copy example topologies
    if [ -d "$SCRIPT_DIR/examples" ]; then
        cp -r "$SCRIPT_DIR/examples/"* "$LIB_DIR/topologies/" 2>/dev/null || true
        log_info "예제 토폴로지: $LIB_DIR/topologies/"
    fi

    # Systemd service
    cat > /etc/systemd/system/gdu@.service << 'SERVICE'
[Unit]
Description=gdu Network Lab - %i
After=network.target
Requires=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/gdu start /var/lib/gdu/topologies/%i.yaml
ExecStop=/usr/local/bin/gdu stop
Restart=on-failure
RestartSec=10
StandardOutput=append:/var/log/gdu/%i.log
StandardError=append:/var/log/gdu/%i.log

# Security hardening
ProtectHome=read-only
NoNewPrivileges=no

[Install]
WantedBy=multi-user.target
SERVICE

    systemctl daemon-reload
    log_info "Systemd 서비스 등록: gdu@<topology>"

    # Shell completion (bash)
    cat > /etc/bash_completion.d/gdu << 'COMP'
_gdu() {
    local cur prev opts
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"

    case "$prev" in
        gdu)
            opts="start stop list console shell validate help"
            COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
            ;;
        start|validate|load)
            COMPREPLY=( $(compgen -f -X '!*.yaml' -- "$cur") )
            ;;
        console)
            # TODO: dynamic node list from running state
            ;;
    esac
}
complete -F _gdu gdu
COMP

    log_info "Bash 자동완성 등록 ✓"
}

# ── Step 5: Configure system ─────────────────────────────────

configure_system() {
    log_step "Step 5/5: 시스템 설정"

    # Enable IP forwarding
    if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
        echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
        sysctl -w net.ipv4.ip_forward=1 > /dev/null
        log_info "IP Forwarding 활성화 ✓"
    fi

    # Add user to kvm group
    REAL_USER="${SUDO_USER:-$USER}"
    if [ "$REAL_USER" != "root" ]; then
        usermod -aG kvm "$REAL_USER" 2>/dev/null || true
        log_info "사용자 '$REAL_USER'를 kvm 그룹에 추가 ✓"
    fi

    # Allow unprivileged bridge creation (optional)
    if [ ! -f /etc/qemu/bridge.conf ]; then
        mkdir -p /etc/qemu
        echo "allow all" > /etc/qemu/bridge.conf
        log_info "QEMU bridge 허용 설정 ✓"
    fi
}

# ── Post-install summary ─────────────────────────────────────

print_summary() {
    echo ""
    echo -e "  ${GREEN}═══════════════════════════════════════════════════${NC}"
    echo -e "  ${GREEN}  gdu 설치 완료!${NC}"
    echo -e "  ${GREEN}═══════════════════════════════════════════════════${NC}"
    echo ""
    echo "  설치 경로:"
    echo "    바이너리     : $BIN_DIR/gdu"
    echo "    설정파일     : $CONFIG_DIR/gdu.conf"
    echo "    이미지 디렉토리: $IMAGE_DIR/"
    echo "    토폴로지     : $LIB_DIR/topologies/"
    echo "    로그         : $LOG_DIR/"
    echo ""
    echo "  사용법:"
    echo -e "    ${CYAN}# QEMU 이미지 준비${NC}"
    echo "    cp cat8000v-17.12.qcow2 $IMAGE_DIR/"
    echo ""
    echo -e "    ${CYAN}# 토폴로지 시작${NC}"
    echo "    sudo gdu start /var/lib/gdu/topologies/ccie-lab.yaml"
    echo ""
    echo -e "    ${CYAN}# Interactive Shell${NC}"
    echo "    sudo gdu shell"
    echo ""
    echo -e "    ${CYAN}# Systemd로 관리${NC}"
    echo "    sudo systemctl start gdu@ccie-lab"
    echo "    sudo systemctl enable gdu@ccie-lab"
    echo ""
    echo -e "    ${CYAN}# 콘솔 접속${NC}"
    echo "    telnet 127.0.0.1 5000"
    echo ""

    if [ ! -e /dev/kvm ]; then
        echo -e "  ${YELLOW}⚠ KVM이 감지되지 않았습니다.${NC}"
        echo "    베어메탈 또는 중첩 가상화 환경에서 사용하세요."
        echo ""
    fi
}

# ── Main ─────────────────────────────────────────────────────

main() {
    print_banner
    check_root
    check_ubuntu
    check_kvm
    install_dependencies
    install_rust
    build_gdu
    install_files
    configure_system
    print_summary
}

main "$@"
