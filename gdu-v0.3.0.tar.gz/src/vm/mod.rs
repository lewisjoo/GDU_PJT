use anyhow::{Context, Result};
use std::collections::HashMap;
use std::process::{Child, Command};
use uuid::Uuid;

use crate::topology::{ConsoleType, NodeConfig, NodeType, Topology};
use crate::memory::{MemoryManager, MemoryConfig};

/// ============================================================
/// QEMU VM Instance - v0.3.0
/// ============================================================

#[derive(Debug)]
pub struct VmInstance {
    pub id: String,
    pub name: String,
    pub node_type: NodeType,
    pub console_type: ConsoleType,
    pub pid: Option<u32>,
    pub console_port: u16,
    pub monitor_port: u16,
    pub vnc_port: Option<u16>,
    pub spice_port: Option<u16>,
    pub novnc_port: Option<u16>,
    pub allocated_mb: u64,
    pub state: VmState,
    process: Option<Child>,
    novnc_process: Option<Child>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum VmState {
    Stopped,
    Starting,
    Running,
    Error(String),
}

impl std::fmt::Display for VmState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            VmState::Stopped => write!(f, "STOPPED"),
            VmState::Starting => write!(f, "STARTING"),
            VmState::Running => write!(f, "RUNNING"),
            VmState::Error(e) => write!(f, "ERROR: {}", e),
        }
    }
}

/// ============================================================
/// VM Manager - v0.3.0 with GUI + Memory Optimization
/// ============================================================

pub struct VmManager {
    pub instances: HashMap<String, VmInstance>,
    pub memory_optimizer: MemoryManager,
    next_console_port: u16,
    next_monitor_port: u16,
    next_vnc_display: u16,
    next_spice_port: u16,
    next_novnc_port: u16,
    qemu_binary: String,
    vnc_base_port: u16,
}

impl VmManager {
    pub fn new(console_base_port: u16) -> Self {
        Self {
            instances: HashMap::new(),
            memory_optimizer: MemoryManager::new(MemoryConfig::default()),
            next_console_port: console_base_port,
            next_monitor_port: console_base_port + 1000,
            next_vnc_display: 0,
            next_spice_port: 5950,
            next_novnc_port: 6080,
            qemu_binary: "qemu-system-x86_64".to_string(),
            vnc_base_port: 5900,
        }
    }

    pub fn new_with_defaults(topo: &Topology) -> Self {
        let mem_config = if let Some(ref opt) = topo.defaults.optimization {
            let (scan, sleep) = match opt.ksm_profile.as_str() {
                "conservative" => (200, 100),
                "aggressive" => (5000, 10),
                "maximum" => (10000, 5),
                _ => (1000, 20),
            };
            MemoryConfig {
                ksm_enabled: opt.ksm,
                ksm_pages_to_scan: scan,
                ksm_sleep_ms: sleep,
                balloon_enabled: opt.balloon,
                hugepages_enabled: opt.hugepages,
                hugepage_size: "2M".to_string(),
                hugepage_count: 0,
                overcommit_ratio: 1.0,
            }
        } else {
            MemoryConfig::default()
        };

        Self {
            instances: HashMap::new(),
            memory_optimizer: MemoryManager::new(mem_config),
            next_console_port: topo.defaults.console_base_port,
            next_monitor_port: topo.defaults.console_base_port + 1000,
            next_vnc_display: 0,
            next_spice_port: topo.defaults.spice_base_port,
            next_novnc_port: topo.defaults.novnc_base_port,
            qemu_binary: "qemu-system-x86_64".to_string(),
            vnc_base_port: topo.defaults.vnc_base_port,
        }
    }

    /// Build QEMU command line arguments for a node
    fn build_qemu_args(
        &mut self,
        name: &str,
        config: &NodeConfig,
        topo: &Topology,
        console_port: u16,
        monitor_port: u16,
    ) -> (Vec<String>, Option<u16>, Option<u16>) {
        let memory = topo.effective_memory(config);
        let vcpus = topo.effective_vcpus(config);

        let mut args: Vec<String> = vec![
            "-name".into(), format!("gdu-{}", name),
            "-m".into(), format!("{}M", memory),
            "-smp".into(), format!("{}", vcpus),
            "-enable-kvm".into(),
            "-cpu".into(), "host".into(),
            "-daemonize".into(),
            "-monitor".into(),
            format!("telnet:0.0.0.0:{},server,nowait", monitor_port),
            "-uuid".into(), Uuid::new_v4().to_string(),
        ];

        // ── Memory Optimization Args (KSM + Balloon + Hugepages) ──
        args.extend(self.memory_optimizer.all_qemu_args());

        // ── Display & Console ──
        let mut vnc_port: Option<u16> = None;
        let mut spice_port: Option<u16> = None;

        match config.console_type {
            ConsoleType::Serial => {
                args.push("-display".into());
                args.push("none".into());
                args.push("-serial".into());
                args.push(format!("telnet:0.0.0.0:{},server,nowait", console_port));
            }
            ConsoleType::Vnc => {
                let display_num = self.next_vnc_display;
                self.next_vnc_display += 1;
                let actual_vnc_port = self.vnc_base_port + display_num;
                vnc_port = Some(actual_vnc_port);

                let listen = config.display.as_ref()
                    .map(|d| d.listen.as_str()).unwrap_or("0.0.0.0");
                let mut vnc_arg = format!("{}:{}", listen, display_num);
                if let Some(ref display) = config.display {
                    if display.password.is_some() {
                        vnc_arg.push_str(",password=on");
                    }
                }
                args.push("-vnc".into());
                args.push(vnc_arg);
                args.push("-serial".into());
                args.push(format!("telnet:0.0.0.0:{},server,nowait", console_port));
                args.push("-vga".into());
                args.push("qxl".into());
            }
            ConsoleType::Spice => {
                let sport = self.next_spice_port;
                self.next_spice_port += 1;
                spice_port = Some(sport);

                let listen = config.display.as_ref()
                    .map(|d| d.listen.as_str()).unwrap_or("0.0.0.0");
                let spice_arg = if let Some(ref display) = config.display {
                    if let Some(ref pw) = display.password {
                        format!("port={},addr={},password={}", sport, listen, pw)
                    } else {
                        format!("port={},addr={},disable-ticketing=on", sport, listen)
                    }
                } else {
                    format!("port={},addr={},disable-ticketing=on", sport, listen)
                };
                args.push("-spice".into());
                args.push(spice_arg);
                args.push("-device".into());
                args.push("qxl-vga,vgamem_mb=64".into());
                args.push("-serial".into());
                args.push(format!("telnet:0.0.0.0:{},server,nowait", console_port));
            }
        }

        // ── Disk ──
        let disk_bus = config.disk.as_ref().map(|d| d.bus.as_str()).unwrap_or("virtio");
        let disk_format = config.disk.as_ref().map(|d| d.format.as_str()).unwrap_or("qcow2");
        let if_type = match disk_bus { "ide" => "ide", "scsi" => "none", _ => "virtio" };

        args.push("-drive".into());
        args.push(format!("file={},if={},format={},snapshot=on", config.image, if_type, disk_format));

        if disk_bus == "scsi" {
            args.push("-device".into());
            args.push("virtio-scsi-pci,id=scsi0".into());
            let last = args.len() - 1;
            args[last] = format!("file={},if=none,format={},id=disk0,snapshot=on", config.image, disk_format);
            args.push("-device".into());
            args.push("scsi-hd,drive=disk0,bus=scsi0.0".into());
        }

        if let Some(ref disk) = config.disk {
            for extra in &disk.extra_disks {
                args.push("-drive".into());
                args.push(format!("file={},if={},format={},snapshot=on", extra.path, if_type, disk_format));
            }
        }

        // ── Boot ──
        if let Some(ref boot) = config.boot {
            args.push("-boot".into());
            args.push(format!("order={}", boot.order));
            if let Some(ref cdrom) = boot.cdrom {
                args.push("-cdrom".into());
                args.push(cdrom.clone());
            }
        }

        // ── Network ──
        for (idx, iface) in config.interfaces.iter().enumerate() {
            let mac = iface.mac.clone().unwrap_or_else(|| generate_mac(name, idx));
            args.push("-device".into());
            args.push(format!("{},netdev=net{},mac={}", iface.model, idx, mac));
            args.push("-netdev".into());
            args.push(format!("tap,id=net{},ifname={}_{},script=no,downscript=no",
                idx, name, iface.name.replace("/", "_")));
        }

        // ── Extra QEMU args ──
        for extra in &config.extra_qemu_args {
            args.push(extra.clone());
        }

        (args, vnc_port, spice_port)
    }

    fn start_novnc(&self, name: &str, vnc_port: u16, novnc_port: u16) -> Option<Child> {
        let result = Command::new("websockify")
            .args(["--web", "/usr/share/novnc",
                &format!("0.0.0.0:{}", novnc_port),
                &format!("127.0.0.1:{}", vnc_port)])
            .spawn();
        match result {
            Ok(child) => {
                println!("  [+] noVNC: http://0.0.0.0:{}/vnc.html → {}", novnc_port, name);
                Some(child)
            }
            Err(_) => {
                eprintln!("  [!] websockify not found. apt install novnc websockify");
                None
            }
        }
    }

    /// Start a single VM
    pub fn start_node(&mut self, name: &str, config: &NodeConfig, topo: &Topology) -> Result<()> {
        if let Some(inst) = self.instances.get(name) {
            if inst.state == VmState::Running {
                anyhow::bail!("Node '{}' is already running", name);
            }
        }

        let console_port = self.next_console_port;
        let monitor_port = self.next_monitor_port;
        self.next_console_port += 1;
        self.next_monitor_port += 1;

        let allocated_mb = topo.effective_memory(config) as u64;
        let (args, vnc_port, spice_port) =
            self.build_qemu_args(name, config, topo, console_port, monitor_port);

        match config.console_type {
            ConsoleType::Serial => println!("  [*] {} (serial:{} mon:{} mem:{}MB)", name, console_port, monitor_port, allocated_mb),
            ConsoleType::Vnc => println!("  [*] {} (VNC:{} serial:{} mon:{} mem:{}MB)", name, vnc_port.unwrap_or(0), console_port, monitor_port, allocated_mb),
            ConsoleType::Spice => println!("  [*] {} (SPICE:{} serial:{} mon:{} mem:{}MB)", name, spice_port.unwrap_or(0), console_port, monitor_port, allocated_mb),
        }

        let child = Command::new(&self.qemu_binary)
            .args(&args)
            .spawn()
            .with_context(|| format!("Failed to start QEMU for '{}'", name))?;

        let pid = child.id();

        let mut novnc_process = None;
        let mut novnc_port_assigned = None;
        if config.console_type == ConsoleType::Vnc {
            if let Some(vport) = vnc_port {
                let nport = config.display.as_ref()
                    .and_then(|d| d.web_port).unwrap_or(self.next_novnc_port);
                self.next_novnc_port += 1;
                novnc_process = self.start_novnc(name, vport, nport);
                novnc_port_assigned = Some(nport);
            }
        }

        self.instances.insert(name.to_string(), VmInstance {
            id: Uuid::new_v4().to_string(),
            name: name.to_string(),
            node_type: config.node_type.clone(),
            console_type: config.console_type.clone(),
            pid: Some(pid),
            console_port, monitor_port, vnc_port, spice_port,
            novnc_port: novnc_port_assigned,
            allocated_mb,
            state: VmState::Running,
            process: Some(child),
            novnc_process,
        });
        println!("  [+] {} started (PID: {})", name, pid);
        Ok(())
    }

    pub fn stop_node(&mut self, name: &str) -> Result<()> {
        let inst = self.instances.get_mut(name)
            .with_context(|| format!("Node '{}' not found", name))?;
        if inst.state == VmState::Stopped {
            println!("  [!] {} already stopped", name);
            return Ok(());
        }
        if let Some(ref mut novnc) = inst.novnc_process {
            let _ = novnc.kill(); let _ = novnc.wait();
        }
        if let Some(ref mut child) = inst.process {
            child.kill().with_context(|| format!("Failed to kill {}", name))?;
            child.wait()?;
        }
        inst.state = VmState::Stopped;
        inst.pid = None;
        inst.process = None;
        inst.novnc_process = None;
        println!("  [-] {} stopped", name);
        Ok(())
    }

    /// Start all nodes with memory optimization
    pub fn start_all(&mut self, topo: &Topology) -> Result<()> {
        println!("\n=== Starting topology: {} ===\n", topo.name);

        // Initialize memory optimization (KSM, Hugepages)
        let total_mem = topo.total_memory_mb();
        self.memory_optimizer.initialize(total_mem)?;

        if topo.has_gui_nodes() {
            println!("  [i] GUI nodes detected - VNC/SPICE enabled\n");
        }

        for (name, config) in &topo.nodes {
            self.start_node(name, config, topo)?;
        }

        println!("\n=== All {} nodes started ===\n", topo.nodes.len());
        self.list_nodes();
        Ok(())
    }

    /// Stop all and cleanup memory optimization
    pub fn stop_all(&mut self) -> Result<()> {
        println!("\n=== Stopping all nodes ===\n");
        let names: Vec<String> = self.instances.keys().cloned().collect();
        for name in names {
            self.stop_node(&name)?;
        }
        self.memory_optimizer.cleanup();
        println!("\n=== All nodes stopped ===");
        Ok(())
    }

    /// Get balloon targets for auto-deflation
    pub fn balloon_targets(&self) -> HashMap<String, (u16, u64)> {
        self.instances.iter()
            .filter(|(_, inst)| inst.state == VmState::Running)
            .map(|(name, inst)| (name.clone(), (inst.monitor_port, inst.allocated_mb)))
            .collect()
    }

    pub fn list_nodes(&self) {
        println!("{:<10} {:<10} {:<8} {:<10} {:<8} {:<8} {:<8} {:<8} {:<8} {}",
            "NODE", "TYPE", "CONSOLE", "STATE", "PID", "MEM(MB)", "SERIAL", "VNC", "SPICE", "noVNC");
        println!("{}", "─".repeat(100));
        for (name, inst) in &self.instances {
            let pid_str = inst.pid.map(|p| p.to_string()).unwrap_or("─".into());
            let vnc_str = inst.vnc_port.map(|p| p.to_string()).unwrap_or("─".into());
            let spice_str = inst.spice_port.map(|p| p.to_string()).unwrap_or("─".into());
            let novnc_str = inst.novnc_port.map(|p| format!(":{}", p)).unwrap_or("─".into());
            println!("{:<10} {:<10} {:<8} {:<10} {:<8} {:<8} {:<8} {:<8} {:<8} {}",
                name, format!("{:?}", inst.node_type), format!("{:?}", inst.console_type),
                inst.state, pid_str, inst.allocated_mb, inst.console_port, vnc_str, spice_str, novnc_str);
        }
    }
}

fn generate_mac(name: &str, idx: usize) -> String {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};
    let mut hasher = DefaultHasher::new();
    name.hash(&mut hasher);
    idx.hash(&mut hasher);
    let hash = hasher.finish();
    format!("52:54:00:{:02x}:{:02x}:{:02x}", (hash >> 16) & 0xFF, (hash >> 8) & 0xFF, hash & 0xFF)
}
