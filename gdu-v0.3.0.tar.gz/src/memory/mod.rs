use anyhow::{Context, Result};
use std::collections::HashMap;
use std::fs;
use std::path::Path;
use std::process::Command;

/// ============================================================
/// Memory Optimization Engine - 근두운 (gdu)
/// ============================================================
///
/// 3-Layer Memory Optimization:
///
///   Layer 1: KSM (Kernel Same-page Merging)
///     커널이 동일한 메모리 페이지를 탐지 → 하나로 병합
///     동일 이미지 VM 10대 → OS 커널 페이지 55% 공유
///
///   Layer 2: Virtio-Balloon
///     VM 내부에서 안 쓰는 메모리를 호스트에 반환
///     QEMU에 `-device virtio-balloon-pci` 자동 추가
///
///   Layer 3: Hugepages (Optional)
///     2MB 대형 페이지로 TLB miss 감소
///     메모리 절감 아님, 성능 10~15% 향상

const KSM_RUN:            &str = "/sys/kernel/mm/ksm/run";
const KSM_PAGES_TO_SCAN:  &str = "/sys/kernel/mm/ksm/pages_to_scan";
const KSM_SLEEP_MS:       &str = "/sys/kernel/mm/ksm/sleep_millisecs";
const KSM_PAGES_SHARED:   &str = "/sys/kernel/mm/ksm/pages_shared";
const KSM_PAGES_SHARING:  &str = "/sys/kernel/mm/ksm/pages_sharing";
const KSM_PAGES_UNSHARED: &str = "/sys/kernel/mm/ksm/pages_unshared";
const KSM_FULL_SCANS:     &str = "/sys/kernel/mm/ksm/full_scans";
const HP_TOTAL:            &str = "/sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages";
const HP_FREE:             &str = "/sys/kernel/mm/hugepages/hugepages-2048kB/free_hugepages";

// ── Configuration ──────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct MemoryConfig {
    pub ksm_enabled: bool,
    pub ksm_pages_to_scan: u32,
    pub ksm_sleep_ms: u32,
    pub balloon_enabled: bool,
    pub hugepages_enabled: bool,
    pub hugepage_size: String,
    pub hugepage_count: u32,
    pub overcommit_ratio: f64,
}

impl Default for MemoryConfig {
    fn default() -> Self {
        Self {
            ksm_enabled: true,
            ksm_pages_to_scan: 1000,
            ksm_sleep_ms: 20,
            balloon_enabled: true,
            hugepages_enabled: false,
            hugepage_size: "2M".to_string(),
            hugepage_count: 0,
            overcommit_ratio: 1.0,
        }
    }
}

impl MemoryConfig {
    /// 공격적 모드: 동일 이미지 VM이 많을 때 최대 절감
    pub fn aggressive() -> Self {
        Self {
            ksm_enabled: true,
            ksm_pages_to_scan: 5000,
            ksm_sleep_ms: 10,
            balloon_enabled: true,
            hugepages_enabled: false,
            hugepage_size: "2M".to_string(),
            hugepage_count: 0,
            overcommit_ratio: 1.5,
        }
    }

    /// 성능 모드: Hugepages + Balloon, KSM 최소
    pub fn performance() -> Self {
        Self {
            ksm_enabled: true,
            ksm_pages_to_scan: 500,
            ksm_sleep_ms: 100,
            balloon_enabled: true,
            hugepages_enabled: true,
            hugepage_size: "2M".to_string(),
            hugepage_count: 0,
            overcommit_ratio: 1.0,
        }
    }
}

// ── Memory Manager ─────────────────────────────────────────

pub struct MemoryManager {
    pub config: MemoryConfig,
    ksm_was_enabled: bool,
    original_pages_to_scan: u32,
    original_sleep_ms: u32,
}

impl MemoryManager {
    pub fn new(config: MemoryConfig) -> Self {
        Self {
            config,
            ksm_was_enabled: false,
            original_pages_to_scan: 0,
            original_sleep_ms: 0,
        }
    }

    /// 전체 메모리 최적화 초기화
    pub fn initialize(&mut self, total_vm_mb: u64) -> Result<()> {
        println!("\n  ☁ Memory Optimization Engine");
        println!("  ─────────────────────────────────────────────");
        println!("  Total VM allocation: {} MB ({:.1} GB)",
            total_vm_mb, total_vm_mb as f64 / 1024.0);
        self.show_host_memory();

        if self.config.ksm_enabled {
            self.enable_ksm()?;
        }
        if self.config.hugepages_enabled {
            self.allocate_hugepages(total_vm_mb as u32)?;
        }
        if self.config.balloon_enabled {
            println!("  [✓] Virtio-Balloon: enabled (auto-inject to VMs)");
        }

        println!("  ─────────────────────────────────────────────\n");
        Ok(())
    }

    // ── KSM ────────────────────────────────────────────────

    fn enable_ksm(&mut self) -> Result<()> {
        if !Path::new(KSM_RUN).exists() {
            println!("  [!] KSM: not available");
            self.config.ksm_enabled = false;
            return Ok(());
        }

        self.ksm_was_enabled = read_sysfs_u32(KSM_RUN).unwrap_or(0) == 1;
        self.original_pages_to_scan = read_sysfs_u32(KSM_PAGES_TO_SCAN).unwrap_or(100);
        self.original_sleep_ms = read_sysfs_u32(KSM_SLEEP_MS).unwrap_or(200);

        write_sysfs(KSM_RUN, "1")
            .with_context(|| "Failed to enable KSM (need root?)")?;
        write_sysfs(KSM_PAGES_TO_SCAN, &self.config.ksm_pages_to_scan.to_string())?;
        write_sysfs(KSM_SLEEP_MS, &self.config.ksm_sleep_ms.to_string())?;

        println!("  [✓] KSM: enabled (scan={} pages, sleep={}ms)",
            self.config.ksm_pages_to_scan, self.config.ksm_sleep_ms);
        Ok(())
    }

    fn restore_ksm(&self) {
        if !self.ksm_was_enabled {
            let _ = write_sysfs(KSM_RUN, "0");
            println!("  [-] KSM: restored to disabled");
        } else {
            let _ = write_sysfs(KSM_PAGES_TO_SCAN, &self.original_pages_to_scan.to_string());
            let _ = write_sysfs(KSM_SLEEP_MS, &self.original_sleep_ms.to_string());
            println!("  [-] KSM: restored original settings");
        }
    }

    // ── Hugepages ──────────────────────────────────────────

    fn setup_hugepages(&self) -> Result<()> {
        if !Path::new(HP_TOTAL).exists() {
            println!("  [!] Hugepages: not available");
            return Ok(());
        }
        if self.config.hugepage_count > 0 {
            write_sysfs(HP_TOTAL, &self.config.hugepage_count.to_string())?;
            let actual = read_sysfs_u32(HP_TOTAL).unwrap_or(0);
            println!("  [✓] Hugepages: {} × 2MB = {} MB", actual, actual * 2);
        } else {
            println!("  [i] Hugepages: auto-allocate at topology start");
        }
        Ok(())
    }

    pub fn allocate_hugepages(&self, total_mb: u32) -> Result<()> {
        if !self.config.hugepages_enabled { return Ok(()); }
        let pages_needed = (total_mb / 2) + 64;
        write_sysfs(HP_TOTAL, &pages_needed.to_string())?;
        let actual = read_sysfs_u32(HP_TOTAL).unwrap_or(0);
        if actual < pages_needed {
            println!("  [!] Hugepages: requested {} got {} (fragmentation?)", pages_needed, actual);
        } else {
            println!("  [✓] Hugepages: {} × 2MB = {} MB", actual, actual * 2);
        }
        Ok(())
    }

    // ── QEMU Args Injection ────────────────────────────────

    /// Balloon device args
    pub fn balloon_qemu_args(&self) -> Vec<String> {
        if !self.config.balloon_enabled { return vec![]; }
        vec![
            "-device".to_string(),
            "virtio-balloon-pci,id=balloon0,deflate-on-oom=on".to_string(),
        ]
    }

    /// Hugepages memory backend args
    pub fn hugepages_qemu_args(&self) -> Vec<String> {
        if !self.config.hugepages_enabled { return vec![]; }
        vec![
            "-mem-path".to_string(),
            "/dev/hugepages".to_string(),
            "-mem-prealloc".to_string(),
        ]
    }

    /// KSM mem-merge args
    pub fn ksm_qemu_args(&self) -> Vec<String> {
        if !self.config.ksm_enabled { return vec![]; }
        vec![
            "-machine".to_string(),
            "mem-merge=on".to_string(),
        ]
    }

    /// 모든 메모리 최적화 QEMU args 통합
    pub fn all_qemu_args(&self) -> Vec<String> {
        let mut args = Vec::new();
        args.extend(self.ksm_qemu_args());
        args.extend(self.balloon_qemu_args());
        args.extend(self.hugepages_qemu_args());
        args
    }

    // ── Statistics ──────────────────────────────────────────

    pub fn ksm_stats(&self) -> KsmStats {
        KsmStats {
            enabled: read_sysfs_u32(KSM_RUN).unwrap_or(0) == 1,
            pages_shared: read_sysfs_u64(KSM_PAGES_SHARED).unwrap_or(0),
            pages_sharing: read_sysfs_u64(KSM_PAGES_SHARING).unwrap_or(0),
            pages_unshared: read_sysfs_u64(KSM_PAGES_UNSHARED).unwrap_or(0),
            full_scans: read_sysfs_u64(KSM_FULL_SCANS).unwrap_or(0),
        }
    }

    pub fn print_stats(&self) {
        println!("\n  ☁ Memory Optimization Status");
        println!("  ─────────────────────────────────────────────");
        self.show_host_memory();

        if self.config.ksm_enabled {
            let ksm = self.ksm_stats();
            let saved_mb = (ksm.pages_sharing * 4) / 1024;
            println!("  KSM:");
            println!("    Pages shared:   {}", ksm.pages_shared);
            println!("    Pages sharing:  {}", ksm.pages_sharing);
            println!("    Pages unshared: {}", ksm.pages_unshared);
            println!("    Memory saved:   ~{} MB", saved_mb);
            println!("    Full scans:     {}", ksm.full_scans);
            if ksm.pages_sharing > 0 && ksm.pages_shared > 0 {
                let ratio = ksm.pages_sharing as f64 / ksm.pages_shared as f64;
                println!("    Sharing ratio:  {:.1}x", ratio);
            }
        }

        if self.config.hugepages_enabled {
            let total = read_sysfs_u32(HP_TOTAL).unwrap_or(0);
            let free = read_sysfs_u32(HP_FREE).unwrap_or(0);
            println!("  Hugepages (2MB):");
            println!("    Total: {} ({} MB)  Free: {} ({} MB)",
                total, total * 2, free, free * 2);
        }

        if self.config.balloon_enabled {
            println!("  Balloon: enabled (query per-VM: 'memory balloon <node>')");
        }

        println!("  ─────────────────────────────────────────────\n");
    }

    /// QEMU monitor를 통해 특정 VM의 balloon 상태 조회
    pub fn query_balloon(&self, monitor_port: u16) -> Result<String> {
        let output = Command::new("bash")
            .args(["-c", &format!(
                "echo 'info balloon' | socat - TCP:127.0.0.1:{},connect-timeout=2",
                monitor_port
            )])
            .output()
            .with_context(|| "Failed to query balloon")?;
        Ok(String::from_utf8_lossy(&output.stdout).to_string())
    }

    /// 특정 VM의 balloon 타겟 설정 (메모리 축소/확장)
    pub fn set_balloon(&self, monitor_port: u16, target_mb: u32) -> Result<()> {
        let output = Command::new("bash")
            .args(["-c", &format!(
                "echo 'balloon {}' | socat - TCP:127.0.0.1:{},connect-timeout=2",
                target_mb, monitor_port
            )])
            .output()
            .with_context(|| "Failed to set balloon")?;
        if output.status.success() {
            println!("  [✓] Balloon target: {} MB", target_mb);
        }
        Ok(())
    }

    /// 토폴로지 기반 메모리 사용량 예측
    pub fn estimate_memory(
        &self,
        nodes: &HashMap<String, crate::topology::NodeConfig>,
        defaults: &crate::topology::NodeDefaults,
    ) -> MemoryEstimate {
        let mut total_allocated: u64 = 0;
        let mut image_groups: HashMap<String, (u32, u32)> = HashMap::new();

        for (_name, config) in nodes {
            let mem = config.memory.unwrap_or(defaults.memory);
            total_allocated += mem as u64;
            let entry = image_groups.entry(config.image.clone()).or_insert((0, mem));
            entry.0 += 1;
        }

        // KSM: 동일 이미지 VM들이 ~55% 메모리 페이지 공유
        let mut ksm_saved: u64 = 0;
        if self.config.ksm_enabled {
            for (_image, (count, mem_per_vm)) in &image_groups {
                if *count > 1 {
                    let shared_per_vm = (*mem_per_vm as f64 * 0.55) as u64;
                    ksm_saved += shared_per_vm * (*count as u64 - 1);
                }
            }
        }

        // Balloon: 평균 15% 미사용 메모리 반환
        let balloon_saved: u64 = if self.config.balloon_enabled {
            (total_allocated as f64 * 0.15) as u64
        } else { 0 };

        let estimated = total_allocated.saturating_sub(ksm_saved).saturating_sub(balloon_saved);
        let with_overcommit = (estimated as f64 / self.config.overcommit_ratio) as u64;

        MemoryEstimate {
            total_allocated_mb: total_allocated,
            ksm_savings_mb: ksm_saved,
            balloon_savings_mb: balloon_saved,
            estimated_actual_mb: estimated,
            with_overcommit_mb: with_overcommit,
            node_count: nodes.len() as u32,
            unique_images: image_groups.len() as u32,
            image_groups: image_groups.iter()
                .map(|(img, (count, mem))| {
                    let short = Path::new(img).file_stem()
                        .and_then(|s| s.to_str()).unwrap_or(img).to_string();
                    (short, *count, *mem)
                })
                .collect(),
        }
    }

    fn show_host_memory(&self) {
        if let Ok(meminfo) = fs::read_to_string("/proc/meminfo") {
            let total = parse_meminfo_kb(&meminfo, "MemTotal") / 1024;
            let available = parse_meminfo_kb(&meminfo, "MemAvailable") / 1024;
            println!("  Host: {} MB total, {} MB available", total, available);
        }
    }

    pub fn cleanup(&self) {
        println!("\n  ☁ Memory cleanup...");
        if self.config.ksm_enabled { self.restore_ksm(); }
        println!("  [✓] Done");
    }
}

// ── Stats Structs ──────────────────────────────────────────

#[derive(Debug)]
pub struct KsmStats {
    pub enabled: bool,
    pub pages_shared: u64,
    pub pages_sharing: u64,
    pub pages_unshared: u64,
    pub full_scans: u64,
}

#[derive(Debug)]
pub struct MemoryEstimate {
    pub total_allocated_mb: u64,
    pub ksm_savings_mb: u64,
    pub balloon_savings_mb: u64,
    pub estimated_actual_mb: u64,
    pub with_overcommit_mb: u64,
    pub node_count: u32,
    pub unique_images: u32,
    pub image_groups: Vec<(String, u32, u32)>,
}

impl MemoryEstimate {
    pub fn print(&self) {
        println!("\n  ☁ Memory Estimate");
        println!("  ─────────────────────────────────────────────");
        println!("  Nodes: {} ({} unique images)\n", self.node_count, self.unique_images);

        println!("  {:<25} {:<6} {:<10} {:<10}", "IMAGE", "COUNT", "PER-VM", "SUBTOTAL");
        println!("  {}", "─".repeat(55));
        for (name, count, mem) in &self.image_groups {
            println!("  {:<25} {:<6} {:<10} {} MB", name, count, format!("{} MB", mem), count * mem);
        }

        println!("\n  Raw allocation:  {:>8} MB", self.total_allocated_mb);
        if self.ksm_savings_mb > 0 {
            let pct = (self.ksm_savings_mb as f64 / self.total_allocated_mb as f64) * 100.0;
            println!("  KSM savings:    -{:>8} MB ({:.0}%)", self.ksm_savings_mb, pct);
        }
        if self.balloon_savings_mb > 0 {
            let pct = (self.balloon_savings_mb as f64 / self.total_allocated_mb as f64) * 100.0;
            println!("  Balloon savings:−{:>8} MB ({:.0}%)", self.balloon_savings_mb, pct);
        }
        println!("  ────────────────────────────");
        println!("  Estimated:       {:>8} MB", self.estimated_actual_mb);
        if self.with_overcommit_mb != self.estimated_actual_mb {
            println!("  With overcommit: {:>8} MB", self.with_overcommit_mb);
        }
        let pct = ((self.total_allocated_mb - self.estimated_actual_mb) as f64
            / self.total_allocated_mb as f64) * 100.0;
        println!("  Total savings:   ~{:.0}%", pct);
        println!("  ─────────────────────────────────────────────\n");
    }
}

// ── sysfs Helpers ──────────────────────────────────────────

fn read_sysfs_u32(path: &str) -> Result<u32> {
    fs::read_to_string(path)?.trim().parse::<u32>()
        .with_context(|| format!("parse error: {}", path))
}

fn read_sysfs_u64(path: &str) -> Result<u64> {
    fs::read_to_string(path)?.trim().parse::<u64>()
        .with_context(|| format!("parse error: {}", path))
}

fn write_sysfs(path: &str, value: &str) -> Result<()> {
    fs::write(path, value)
        .with_context(|| format!("write '{}' to {} failed (root?)", value, path))
}

fn parse_meminfo_kb(meminfo: &str, key: &str) -> u64 {
    meminfo.lines()
        .find(|l| l.starts_with(key))
        .and_then(|l| l.split_whitespace().nth(1))
        .and_then(|v| v.parse().ok())
        .unwrap_or(0)
}
