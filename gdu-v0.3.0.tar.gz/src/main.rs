mod console;
mod memory;
mod network;
mod topology;
mod vm;

use anyhow::Result;
use clap::{Parser, Subcommand};
use std::io::{self, Write};
use std::path::PathBuf;

use console::ConsoleManager;
use network::NetworkManager;
use topology::Topology;
use vm::VmManager;

/// ============================================================
///  근두운 (Gunduwoon) - gdu v0.3.0
/// ============================================================
///  筋斗雲 - 손오공의 구름처럼, 어디서나 가볍게 네트워크 랩을
///  펼칠 수 있는 QEMU 기반 에뮬레이션 매니저.
///
///  Usage:
///    gdu start lab.yaml         Start a topology
///    gdu shell                  Interactive management shell
///    gdu list                   Show running nodes
///    gdu console R1             Connect to node console
///    gdu vnc ISE                VNC GUI access
///    gdu browser ISE            noVNC web access
///    gdu stop                   Stop all nodes

#[derive(Parser)]
#[command(
    name = "gdu",
    version = "0.2.0",
    about = "근두운(Gunduwoon) - Lightweight QEMU network lab emulator"
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Start topology from YAML file
    Start {
        topology: PathBuf,
    },
    /// Stop all running nodes
    Stop,
    /// List all nodes and their status
    List,
    /// Connect to a node's console (auto-detect serial/VNC/SPICE)
    Console {
        node: String,
        #[arg(short = 'w', long)]
        window: bool,
        #[arg(short = 's', long)]
        serial: bool,
    },
    /// Open VNC connection to a GUI node
    Vnc {
        node: String,
    },
    /// Open SPICE connection to a GUI node
    Spice {
        node: String,
    },
    /// Open noVNC in browser for a GUI node
    Browser {
        node: String,
    },
    /// Interactive management shell
    Shell {
        #[arg(short, long)]
        topology: Option<PathBuf>,
    },
    /// Validate a topology file
    Validate {
        topology: PathBuf,
    },
}

fn main() -> Result<()> {
    print_banner();

    let cli = Cli::parse();

    match cli.command {
        Commands::Start { topology } => cmd_start(&topology),
        Commands::Stop => cmd_stop(),
        Commands::List => cmd_list(),
        Commands::Console { node, window, serial } => cmd_console(&node, window, serial),
        Commands::Vnc { node } => cmd_vnc(&node),
        Commands::Spice { node } => cmd_spice(&node),
        Commands::Browser { node } => cmd_browser(&node),
        Commands::Shell { topology } => cmd_shell(topology),
        Commands::Validate { topology } => cmd_validate(&topology),
    }
}

fn cmd_start(path: &PathBuf) -> Result<()> {
    let topo = Topology::from_file(path)?;
    println!("  Topology: {} ({} nodes, {} links)",
        topo.name, topo.nodes.len(), topo.links.len());

    if topo.has_gui_nodes() {
        println!("  GUI nodes detected - VNC/SPICE will be enabled");
        check_gui_dependencies();
    }

    let mut net_mgr = NetworkManager::new();
    net_mgr.create_bridges(&topo.links)?;

    for (node_name, config) in &topo.nodes {
        for iface in &config.interfaces {
            let tap_name = format!("{}_{}", node_name, iface.name.replace("/", "_"));
            net_mgr.create_tap(&tap_name, &iface.bridge)?;
        }
    }

    let mut vm_mgr = VmManager::new_with_defaults(&topo);
    vm_mgr.start_all(&topo)?;

    ConsoleManager::list_consoles(&vm_mgr.instances);

    println!("Press Ctrl+C to stop all nodes...\n");
    let (tx, rx) = std::sync::mpsc::channel();
    ctrlc_handler(tx);
    rx.recv()?;

    vm_mgr.stop_all()?;
    net_mgr.cleanup()?;
    Ok(())
}

fn cmd_stop() -> Result<()> {
    println!("  Sending stop signal to all gdu instances...");
    println!("  (TODO: implement via PID file / Unix socket)");
    Ok(())
}

fn cmd_list() -> Result<()> {
    println!("  (TODO: read state from running gdu daemon)");
    Ok(())
}

fn cmd_console(node: &str, _window: bool, _serial: bool) -> Result<()> {
    println!("  (TODO: read port from running state for {})", node);
    Ok(())
}

fn cmd_vnc(node: &str) -> Result<()> {
    println!("  (TODO: connect VNC for {})", node);
    Ok(())
}

fn cmd_spice(node: &str) -> Result<()> {
    println!("  (TODO: connect SPICE for {})", node);
    Ok(())
}

fn cmd_browser(node: &str) -> Result<()> {
    println!("  (TODO: open browser for {})", node);
    Ok(())
}

fn cmd_validate(path: &PathBuf) -> Result<()> {
    let topo = Topology::from_file(path)?;
    println!("  [OK] Topology '{}' is valid", topo.name);
    println!("       Nodes: {}", topo.nodes.len());
    println!("       Links: {}", topo.links.len());
    for (name, config) in &topo.nodes {
        let console_str = format!("{:?}", config.console_type);
        println!("         {} ({:?}) console={} - {} interfaces",
            name, config.node_type, console_str, config.interfaces.len());
    }
    if topo.has_gui_nodes() {
        println!("\n  [i] This topology contains GUI nodes (VNC/SPICE)");
        println!("      Required: novnc, websockify, tigervnc-viewer or virt-viewer");
    }
    Ok(())
}

fn cmd_shell(topo_path: Option<PathBuf>) -> Result<()> {
    let mut topo: Option<Topology> = None;
    let mut vm_mgr: Option<VmManager> = None;
    let mut net_mgr = NetworkManager::new();

    if let Some(path) = topo_path {
        let t = Topology::from_file(&path)?;
        println!("  Loaded: {}", t.name);
        topo = Some(t);
    }

    println!("\n  Type 'help' for commands\n");

    loop {
        print!("gdu> ");
        io::stdout().flush()?;

        let mut input = String::new();
        if io::stdin().read_line(&mut input)? == 0 {
            break;
        }

        let parts: Vec<&str> = input.trim().split_whitespace().collect();
        if parts.is_empty() {
            continue;
        }

        match parts[0] {
            "help" | "?" => print_shell_help(),

            "load" => {
                if parts.len() < 2 {
                    println!("  Usage: load <topology.yaml>");
                    continue;
                }
                match Topology::from_file(&PathBuf::from(parts[1])) {
                    Ok(t) => {
                        println!("  [OK] Loaded topology: {}", t.name);
                        if t.has_gui_nodes() {
                            println!("  [i] GUI nodes detected - VNC/SPICE will be enabled");
                        }
                        topo = Some(t);
                    }
                    Err(e) => println!("  [ERR] {}", e),
                }
            }

            "start" => {
                if let Some(ref t) = topo {
                    if t.has_gui_nodes() {
                        check_gui_dependencies();
                    }
                    if let Err(e) = net_mgr.create_bridges(&t.links) {
                        println!("  [ERR] Network setup failed: {}", e);
                        continue;
                    }
                    for (node_name, config) in &t.nodes {
                        for iface in &config.interfaces {
                            let tap = format!("{}_{}", node_name,
                                iface.name.replace("/", "_"));
                            let _ = net_mgr.create_tap(&tap, &iface.bridge);
                        }
                    }
                    let mut mgr = VmManager::new_with_defaults(t);
                    if let Err(e) = mgr.start_all(t) {
                        println!("  [ERR] {}", e);
                    }
                    vm_mgr = Some(mgr);
                } else {
                    println!("  [!] No topology loaded. Use: load <file.yaml>");
                }
            }

            "stop" => {
                if let Some(ref mut mgr) = vm_mgr {
                    mgr.stop_all()?;
                }
                net_mgr.cleanup()?;
            }

            "list" | "ls" => {
                if let Some(ref mgr) = vm_mgr {
                    mgr.list_nodes();
                } else {
                    println!("  No nodes running.");
                }
            }

            "bridges" | "net" => {
                net_mgr.list_bridges();
            }

            "console" | "telnet" => {
                if parts.len() < 2 {
                    if let Some(ref mgr) = vm_mgr {
                        ConsoleManager::list_consoles(&mgr.instances);
                    }
                    continue;
                }
                let node = parts[1];
                if let Some(ref mgr) = vm_mgr {
                    if let Some(inst) = mgr.instances.get(node) {
                        ConsoleManager::connect(node, inst)?;
                    } else {
                        println!("  [!] Node '{}' not found", node);
                    }
                }
            }

            "serial" => {
                if parts.len() < 2 {
                    println!("  Usage: serial <node>");
                    continue;
                }
                let node = parts[1];
                if let Some(ref mgr) = vm_mgr {
                    if let Some(inst) = mgr.instances.get(node) {
                        ConsoleManager::connect_serial(node, inst.console_port)?;
                    } else {
                        println!("  [!] Node '{}' not found", node);
                    }
                }
            }

            "vnc" => {
                if parts.len() < 2 {
                    println!("  Usage: vnc <node>");
                    continue;
                }
                let node = parts[1];
                if let Some(ref mgr) = vm_mgr {
                    if let Some(inst) = mgr.instances.get(node) {
                        if let Some(vnc_port) = inst.vnc_port {
                            ConsoleManager::connect_vnc(node, vnc_port, inst.novnc_port)?;
                        } else {
                            println!("  [!] {} does not have VNC enabled", node);
                        }
                    } else {
                        println!("  [!] Node '{}' not found", node);
                    }
                }
            }

            "spice" => {
                if parts.len() < 2 {
                    println!("  Usage: spice <node>");
                    continue;
                }
                let node = parts[1];
                if let Some(ref mgr) = vm_mgr {
                    if let Some(inst) = mgr.instances.get(node) {
                        if let Some(spice_port) = inst.spice_port {
                            ConsoleManager::connect_spice(node, spice_port)?;
                        } else {
                            println!("  [!] {} does not have SPICE enabled", node);
                        }
                    } else {
                        println!("  [!] Node '{}' not found", node);
                    }
                }
            }

            "browser" | "web" | "novnc" => {
                if parts.len() < 2 {
                    println!("  Usage: browser <node>");
                    continue;
                }
                let node = parts[1];
                if let Some(ref mgr) = vm_mgr {
                    if let Some(inst) = mgr.instances.get(node) {
                        if let Some(novnc_port) = inst.novnc_port {
                            let url = format!(
                                "http://localhost:{}/vnc.html?host=localhost&port={}",
                                novnc_port, novnc_port
                            );
                            println!("  [*] Opening: {}", url);
                            let _ = open_browser(&url);
                        } else if let Some(vnc_port) = inst.vnc_port {
                            println!("  [!] noVNC not running for {}.", node);
                            println!("      Use VNC client: vncviewer 127.0.0.1:{}", vnc_port);
                        } else {
                            println!("  [!] {} is not a GUI node", node);
                        }
                    } else {
                        println!("  [!] Node '{}' not found", node);
                    }
                }
            }

            "topo" | "topology" => {
                if let Some(ref t) = topo {
                    println!("  Topology: {}", t.name);
                    println!("  Total VM memory: {} MB ({:.1} GB)",
                        t.total_memory_mb(), t.total_memory_mb() as f64 / 1024.0);
                    println!("  Nodes:");
                    for (name, config) in &t.nodes {
                        let console_str = format!("{:?}", config.console_type);
                        println!("    {} ({:?}) [{}]", name, config.node_type, console_str);
                        for iface in &config.interfaces {
                            println!("      {} → {}", iface.name, iface.bridge);
                        }
                    }
                    println!("  Links:");
                    for link in &t.links {
                        println!("    {}", link.name);
                    }
                } else {
                    println!("  No topology loaded.");
                }
            }

            // ── Memory optimization commands ──
            "memory" | "mem" => {
                if let Some(ref mgr) = vm_mgr {
                    mgr.memory_optimizer.print_stats();
                } else {
                    let opt = memory::MemoryManager::new(memory::MemoryConfig::default());
                    opt.print_stats();
                }
            }

            "ksm" => {
                if let Some(ref mgr) = vm_mgr {
                    let stats = mgr.memory_optimizer.ksm_stats();
                    let saved_mb = (stats.pages_sharing * 4) / 1024;
                    println!("\n  ── KSM Statistics ──");
                    println!("  Pages shared:   {}", stats.pages_shared);
                    println!("  Pages sharing:  {}", stats.pages_sharing);
                    println!("  Pages unshared: {}", stats.pages_unshared);
                    println!("  Memory saved:   ~{} MB", saved_mb);
                    println!("  Full scans:     {}\n", stats.full_scans);
                } else {
                    println!("  [!] No running VMs.");
                }
            }

            "balloon" => {
                if parts.len() >= 2 {
                    let node = parts[1];
                    if let Some(ref mgr) = vm_mgr {
                        if let Some(inst) = mgr.instances.get(node) {
                            if parts.len() >= 3 {
                                if let Ok(target) = parts[2].parse::<u32>() {
                                    let _ = mgr.memory_optimizer.set_balloon(inst.monitor_port, target);
                                } else {
                                    println!("  Usage: balloon <node> <target_mb>");
                                }
                            } else {
                                match mgr.memory_optimizer.query_balloon(inst.monitor_port) {
                                    Ok(info) => println!("  {}: {}", node, info.trim()),
                                    Err(e) => println!("  [!] {}: {}", node, e),
                                }
                            }
                        } else {
                            println!("  [!] Node '{}' not found", node);
                        }
                    }
                } else {
                    println!("  Usage: balloon <node> [target_mb]");
                    println!("  Query:  balloon R1");
                    println!("  Set:    balloon R1 2048");
                }
            }

            "estimate" => {
                if let Some(ref t) = topo {
                    let mem_mgr = if let Some(ref mgr) = vm_mgr {
                        &mgr.memory_optimizer
                    } else {
                        &memory::MemoryManager::new(memory::MemoryConfig::default())
                    };
                    let est = mem_mgr.estimate_memory(&t.nodes, &t.defaults);
                    est.print();
                } else {
                    println!("  [!] No topology loaded.");
                }
            }

            "quit" | "exit" | "q" => {
                if let Some(ref mut mgr) = vm_mgr {
                    mgr.stop_all()?;
                }
                net_mgr.cleanup()?;
                println!("  Goodbye!");
                break;
            }

            _ => {
                println!("  Unknown command: '{}'. Type 'help' for commands.", parts[0]);
            }
        }
    }

    Ok(())
}

// ── Helpers ────────────────────────────────────────────────

fn print_banner() {
    println!(r#"
  ╔═══════════════════════════════════════════════════╗
  ║                                                   ║
  ║     ☁  근두운 (筋斗雲) - Gunduwoon  ☁            ║
  ║                                                   ║
  ║     gdu v0.3.0                                    ║
  ║     Lightweight QEMU Network Lab Emulator         ║
  ║     Run anywhere. Any hardware. Simple.           ║
  ║                                                   ║
  ╚═══════════════════════════════════════════════════╝
"#);
}

fn print_shell_help() {
    println!(r#"
  근두운 (gdu) Interactive Shell:
  ─────────────────────────────────────────────────
  load <file.yaml>    Load a topology file
  start               Start all nodes
  stop                Stop all nodes
  list / ls           List nodes and status
  bridges / net       List network bridges
  topo                Show topology details

  Console Access:
  ─────────────────────────────────────────────────
  console <node>      Auto-detect: serial/VNC/SPICE
  console             List all console ports
  serial <node>       Force serial console (telnet)
  vnc <node>          Open VNC viewer
  spice <node>        Open SPICE viewer
  browser <node>      Open noVNC in web browser

  Memory Optimization:
  ─────────────────────────────────────────────────
  memory / mem        Host + KSM + Hugepages status
  ksm                 KSM statistics (saved memory)
  balloon <node>      Query VM balloon status
  balloon <node> <mb> Set balloon target (shrink)
  estimate            Predict memory usage for topology

  Other:
  ─────────────────────────────────────────────────
  quit / exit         Stop everything and exit
  help / ?            Show this help
  ─────────────────────────────────────────────────
"#);
}

fn check_gui_dependencies() {
    println!("\n  [i] Checking GUI dependencies...");
    let checks = [
        ("websockify", "noVNC websocket proxy", "apt install websockify"),
        ("novnc", "noVNC web client", "apt install novnc"),
        ("vncviewer", "TigerVNC viewer", "apt install tigervnc-viewer"),
        ("remote-viewer", "SPICE/VNC viewer", "apt install virt-viewer"),
    ];
    for (binary, desc, install) in &checks {
        let found = std::process::Command::new("which")
            .arg(binary)
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        if found {
            println!("    [✓] {} ({})", desc, binary);
        } else {
            println!("    [✗] {} - install: {}", desc, install);
        }
    }
    println!();
}

fn open_browser(url: &str) -> Result<()> {
    let browsers = ["xdg-open", "gnome-open", "wslview", "firefox", "chromium-browser"];
    for browser in &browsers {
        if std::process::Command::new(browser).arg(url).spawn().is_ok() {
            return Ok(());
        }
    }
    println!("  [!] Could not open browser. Visit: {}", url);
    Ok(())
}

fn ctrlc_handler(tx: std::sync::mpsc::Sender<()>) {
    let _ = ctrlc::set_handler(move || {
        println!("\n  [!] Ctrl+C received, shutting down...");
        let _ = tx.send(());
    });
}
